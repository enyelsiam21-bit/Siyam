import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.siambhai.wifispecial',
  appName: 'Siam Bhai WiFi Special',
  webDir: 'dist',
  plugins: {
    LocalNotifications: {
      iconColor: '#00ff66',
    },
  },
};

export default config;
