/**
 * Cloud Functions — এডমিন প্যানেল ↔ সব ফোন
 *
 * 1) sendBroadcast: এডমিন মেসেজ জমা দিলে ৩০ সেকেন্ড অপেক্ষা করে "all" টপিকে
 *    (যত ফোন অ্যাপ ইনস্টল করেছে সবাই) একই মুহূর্তে পুশ নোটিফিকেশন পাঠায়।
 *    ফোন অফলাইনে থাকলে Google ম্যাসেজ ধরে রাখে (TTL পর্যন্ত) এবং নেট আসলে পৌঁছে দেয়।
 * 2) notifyAdminOnScan: কেউ স্ক্যান করলে (অফলাইনে করলেও, নেট আসার পর) এডমিনের ফোনে নোটিফিকেশন যায়।
 */
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { setGlobalOptions } = require('firebase-functions/v2');
const admin = require('firebase-admin');

admin.initializeApp();

// Firestore ডাটাবেস যে লোকেশনে বানাবেন (asia-south1 = মুম্বাই) সেটাই এখানে দিন
setGlobalOptions({ region: 'asia-south1', maxInstances: 5 });

// ফোন অফলাইনে থাকলে মেসেজ কতক্ষণ ধরে রাখা হবে
const TTL_MS = 24 * 60 * 60 * 1000;
const MAX_DELAY_SECONDS = 60;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

exports.sendBroadcast = onDocumentCreated(
  { document: 'broadcasts/{id}', timeoutSeconds: 120 },
  async (event) => {
    const snap = event.data;
    if (!snap) return;
    const data = snap.data();

    const delay = Math.min(Math.max(Number(data.delaySeconds) || 30, 0), MAX_DELAY_SECONDS);
    await sleep(delay * 1000);

    const text = String(data.text || '').slice(0, 500);
    if (!text) return;

    await admin.messaging().send({
      topic: 'all',
      notification: { title: '⚡ সিয়াম ভাই Free WiFi', body: text },
      data: { type: 'broadcast', broadcastId: snap.id },
      android: {
        priority: 'high',
        ttl: TTL_MS,
        notification: { channelId: 'wifi-broadcast' },
      },
    });

    // অ্যাপের ভেতরে "সর্বশেষ মেসেজ" দেখানোর জন্য
    await snap.ref.update({ status: 'sent', sentAtMs: Date.now() });
  }
);

exports.notifyAdminOnScan = onDocumentCreated('tickets/{id}', async (event) => {
  const snap = event.data;
  if (!snap) return;
  const d = snap.data();
  const device = String(d.deviceName || 'অজানা ডিভাইস').slice(0, 60);

  await admin.messaging().send({
    topic: 'admin',
    notification: { title: '📡 নতুন ওয়াইফাই স্ক্যান', body: `ডিভাইস: ${device}` },
    data: { type: 'scan', ticketId: snap.id },
    android: {
      priority: 'high',
      ttl: TTL_MS,
      notification: { channelId: 'wifi-broadcast' },
    },
  });
});
