// `npx cap add android` এর পর চালান (npm run android:setup / android:sync নিজেই চালায়)।
// কাজ: ১) AndroidManifest-এ পারমিশন  ২) অ্যালার্ম সাউন্ড কপি  ৩) google-services.json কপি
import fs from 'node:fs';
import path from 'node:path';

const manifestFile = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(manifestFile)) {
  console.error('AndroidManifest.xml পাওয়া যায়নি। আগে `npx cap add android` চালান।');
  process.exit(1);
}

let xml = fs.readFileSync(manifestFile, 'utf8');
let added = 0;

const perms = [
  'android.permission.INTERNET',
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.SCHEDULE_EXACT_ALARM',
  'android.permission.RECEIVE_BOOT_COMPLETED',
  'android.permission.VIBRATE',
  'android.permission.WAKE_LOCK',
];
for (const p of perms) {
  if (!xml.includes(`"${p}"`)) {
    xml = xml.replace('</manifest>', `    <uses-permission android:name="${p}" />\n</manifest>`);
    added++;
  }
}

// FCM পুশ নোটিফিকেশন ডিফল্টভাবে "wifi-broadcast" চ্যানেলে (কাস্টম সাউন্ডসহ) দেখাবে
const channelMeta = 'com.google.firebase.messaging.default_notification_channel_id';
if (!xml.includes(channelMeta)) {
  xml = xml.replace(
    '</application>',
    `    <meta-data android:name="${channelMeta}" android:value="wifi-broadcast" />\n    </application>`
  );
  added++;
}
fs.writeFileSync(manifestFile, xml);
console.log(`✅ AndroidManifest.xml আপডেট হয়েছে (${added}টি নতুন এন্ট্রি)`);

// অ্যালার্ম সাউন্ড
const rawSrc = 'resources/android/raw';
const rawDst = 'android/app/src/main/res/raw';
if (fs.existsSync(rawSrc)) {
  fs.mkdirSync(rawDst, { recursive: true });
  let n = 0;
  for (const f of fs.readdirSync(rawSrc)) {
    if (/\.(wav|mp3|ogg)$/i.test(f)) {
      fs.copyFileSync(path.join(rawSrc, f), path.join(rawDst, f));
      n++;
    }
  }
  console.log(`✅ ${n}টি সাউন্ড ফাইল কপি হয়েছে`);
}

// Firebase কনফিগ
if (fs.existsSync('google-services.json')) {
  fs.copyFileSync('google-services.json', 'android/app/google-services.json');
  console.log('✅ google-services.json কপি হয়েছে');
} else {
  console.warn(
    '⚠️  google-services.json পাওয়া যায়নি — এডমিন থেকে সব ফোনে পুশ নোটিফিকেশন কাজ করবে না।\n' +
      '   FIREBASE_SETUP.md দেখে ফাইলটি প্রজেক্টের রুটে রেখে আবার npm run android:sync চালান।\n' +
      '   (ভোর ৫টা/বিকেল ৫টার অ্যালার্ম এটা ছাড়াই কাজ করবে)'
  );
}
