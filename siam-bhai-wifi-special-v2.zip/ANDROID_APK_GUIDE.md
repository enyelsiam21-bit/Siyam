# APK বানানোর ধাপ

## কম্পিউটারে (Node.js 20+ ও Android Studio লাগবে)
```
npm install
npm run android:setup
npm run android:open
```
Android Studio খুললে: **Build → Build Bundle(s)/APK(s) → Build APK(s)**
APK: `android/app/build/outputs/apk/debug/app-debug.apk`

কোড বদলালে: `npm run android:sync` → আবার APK build।

## অটো অ্যালার্ম (ইন্টারনেট ছাড়াই চলে)
| সময় | কী হবে |
|---|---|
| ভোর ৫:০০ | "সিয়াম ভাইয়ের wifi চালু করা হয়েছে" — **১০ বার** (১০ সেকেন্ড পরপর) |
| বিকেল ৫:০০ | "সিয়াম ভাই wifi বন্ধ করা হচ্ছে, আবার কালকে চালু হবে" |
| শুক্রবার | সারাদিন wifi বন্ধ, কোনো অ্যালার্ম নেই (স্ক্যান করলে অ্যাপ বলবে wifi বন্ধ) |

- অ্যাপ বন্ধ থাকলে: ফোনের অ্যালার্ম নোটিফিকেশন বাজবে (সাউন্ড: `resources/android/raw/`)।
  নিজের ভয়েস রেকর্ড করে একই নামে বসালে সেটাই বাজবে।
- অ্যাপ খোলা থাকলে (বা নোটিফিকেশনে ট্যাপ করলে): অ্যাপ বাংলা ভয়েসে ঘোষণা বলবে।
  বাংলা ভয়েসের জন্য ফোনে **Google Text-to-speech** ও বাংলা ভাষা ডাউনলোড থাকতে হবে।

## ফোনে যা করতে হবে
- নোটিফিকেশন পারমিশন → **Allow**
- Android 12+: "Alarms & reminders" পেজ একবার খুলবে → **Allow**
- Xiaomi/Oppo/Vivo/Realme/Samsung: Settings → Apps → এই অ্যাপ → Battery → **No restrictions**
  এবং **Autostart চালু**। না দিলে কোম্পানির ব্যাটারি সেভার অ্যালার্ম আটকে দিতে পারে।

## এডমিন থেকে সব ফোনে মেসেজ
`FIREBASE_SETUP.md` দেখুন।

## কম্পিউটার ছাড়া, শুধু মোবাইল দিয়ে APK (GitHub Actions)
`.github/workflows/build-apk.yml` ফাইলটি GitHub-এর সার্ভারে APK বানিয়ে দেয়।
১) github.com-এ ফ্রি অ্যাকাউন্ট → নতুন Private repository
২) Add file → Upload files → এই zip ফাইলটি (খোলা ছাড়া) আপলোড → Commit
৩) Add file → Create new file → নামে `.github/workflows/build-apk.yml` লিখুন → ফাইলের লেখা পেস্ট → Commit
৪) (Firebase ব্যবহার করলে) Settings → Secrets and variables → Actions-এ `VITE_FIREBASE_*` ও `GOOGLE_SERVICES_JSON` দিন
৫) Actions ট্যাব → Build APK → Run workflow → ৫–১০ মিনিট পর → Artifacts থেকে `siam-bhai-apk` ডাউনলোড
