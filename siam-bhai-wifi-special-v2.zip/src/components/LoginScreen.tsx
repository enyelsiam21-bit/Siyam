import React, { useState } from 'react';
import { Eye, EyeOff, Terminal, ShieldAlert, Cpu, Sparkles, KeySquare } from 'lucide-react';
import { validateLoginPassword, validateAdminPassword } from '../utils/rules';
import { adminSignIn, cloudEnabled } from '../utils/cloud';
import { soundManager } from '../utils/audio';

interface LoginScreenProps {
  onLoginSuccess: (isAdmin?: boolean) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playTick();
    setIsSubmitting(true);
    setError(null);

    if (showAdminLogin) {
      if (validateAdminPassword(password)) {
        if (cloudEnabled) adminSignIn(password.trim());
        soundManager.playStepChime();
        setTimeout(() => {
          onLoginSuccess(true);
        }, 300);
      } else {
        setError('[ERROR]: ACCESS DENIED • INVALID ROOT KEY');
        setIsSubmitting(false);
      }
      return;
    }

    const validation = validateLoginPassword(password);
    if (validation.isValid) {
      if (validation.isAdmin && cloudEnabled) adminSignIn(password.trim());
      soundManager.playStepChime();
      setTimeout(() => {
        onLoginSuccess(validation.isAdmin);
      }, 300);
    } else {
      setError(validation.message);
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative z-10">
      <div className="w-full max-w-sm relative">
        <div className="glass-card-glow rounded-3xl p-6 sm:p-8 border border-[#00ff66]/40 shadow-2xl backdrop-blur-2xl relative overflow-hidden">
          {/* Top Cyber Terminal Header line */}
          <div className="flex items-center justify-between text-[10px] font-mono text-[#00ff66] mb-5 border-b border-[#00ff66]/20 pb-2">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#00ff66] animate-ping"></span>
              PORT 3000 • QUANTUM ENCRYPTED
            </span>
            <span className="text-[#00f0ff] font-bold">NODE_ID: #SIAM-01</span>
          </div>

          {/* Cyber Terminal Icon */}
          <div className="flex justify-center mb-5">
            <div className="relative">
              <div className="w-18 h-18 rounded-2xl bg-gradient-to-tr from-[#021a12] via-[#052e1e] to-[#01140d] border border-[#00ff66] flex items-center justify-center shadow-lg shadow-[#00ff66]/20 animate-float">
                {showAdminLogin ? (
                  <ShieldAlert className="w-9 h-9 text-[#00f0ff]" />
                ) : (
                  <Terminal className="w-9 h-9 text-[#00ff66]" />
                )}
              </div>
              <div className="absolute -top-1 -right-1 bg-[#00ff66] text-black p-1 rounded-full shadow">
                <Sparkles className="w-3.5 h-3.5 fill-black" />
              </div>
            </div>
          </div>

          {/* Requested Exact Title: ⚡ SIYAM INFINITY NETWORK */}
          <div className="text-center mb-6">
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight font-mono text-cyber-green flex items-center justify-center gap-1.5 flex-wrap">
              <span>⚡</span>
              <span>SIYAM INFINITY NETWORK</span>
            </h1>
            <p className="text-[11px] font-mono text-[#00f0ff] mt-2 tracking-wide uppercase">
              {showAdminLogin
                ? '[ROOT TERMINAL AUTHENTICATION]'
                : '[SYSTEM ONLINE • ENTER ACCESS KEY]'}
            </p>
          </div>

          {/* Cyber Hacker Input Form */}
          <form onSubmit={handleSubmit} className="space-y-4 font-mono">
            <div>
              <div className="relative">
                <input
                  id="login-password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder={showAdminLogin ? 'ENTER ROOT PASSWORD...' : 'ENTER ACCESS KEY...'}
                  autoComplete="current-password"
                  className="w-full pl-4 pr-11 py-3 bg-[#030d12] border border-[#00ff66]/50 focus:border-[#00ff66] focus:ring-2 focus:ring-[#00ff66]/30 rounded-xl text-[#00ff66] placeholder-slate-600 text-xs sm:text-sm outline-none transition-all font-mono tracking-wider"
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-[#00ff66] cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="p-2.5 bg-rose-950/80 border border-rose-500/50 rounded-xl text-rose-300 text-xs text-center font-mono animate-shake">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-[#00ff66] to-[#00f0ff] hover:from-[#22c55e] hover:to-[#06b6d4] text-slate-950 font-black rounded-xl shadow-lg shadow-[#00ff66]/30 transition-all transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer flex items-center justify-center gap-2 text-xs sm:text-sm tracking-wider uppercase disabled:opacity-50"
            >
              <KeySquare className="w-4 h-4" />
              <span>{isSubmitting ? 'AUTHENTICATING...' : 'ACCESS TERMINAL'}</span>
            </button>
          </form>

          {/* Discreet Admin Entry */}
          <div className="mt-5 pt-3.5 border-t border-[#00ff66]/20 text-center font-mono">
            <button
              type="button"
              onClick={() => {
                setShowAdminLogin(!showAdminLogin);
                setError(null);
                setPassword('');
              }}
              className="text-[11px] text-slate-500 hover:text-[#00ff66] transition-colors cursor-pointer"
            >
              {showAdminLogin ? '← USER TERMINAL' : '🔒 ROOT ADMIN TERMINAL'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
