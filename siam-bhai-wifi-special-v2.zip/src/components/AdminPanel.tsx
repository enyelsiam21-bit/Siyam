import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Bell,
  Smartphone,
  CheckCircle,
  Wifi,
  ArrowLeft,
  ShieldCheck,
  Terminal,
  Activity,
  Cpu,
} from 'lucide-react';
import {
  getAdminBroadcastMessage,
  saveAdminBroadcastMessage,
  getScanAlertTickets,
  markTicketResolved,
  DEFAULT_5AM_MESSAGE,
} from '../utils/rules';
import { ScanAlertTicket } from '../types';
import { soundManager } from '../utils/audio';
import {
  cloudEnabled,
  adminSignIn,
  onAdminAuthChange,
  subscribeTickets,
  resolveTicketInCloud,
  sendBroadcastToCloud,
} from '../utils/cloud';
import { subscribeAdminTopic } from '../utils/push';
import {
  isNativeApp,
  getScheduledAlarmCount,
  scheduleTestAlarms,
  scheduleWifiAlarms,
} from '../utils/nativeNotifications';
import { BROADCAST_DELAY_SECONDS, WIFI_ON_MESSAGE, WIFI_OFF_MESSAGE } from '../utils/schedule';

interface AdminPanelProps {
  onBackToUserView: () => void;
  onLogout: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ onBackToUserView, onLogout }) => {
  const [currentMessage, setCurrentMessage] = useState<string>(getAdminBroadcastMessage());
  const [draftMessage, setDraftMessage] = useState<string>('');
  const [tickets, setTickets] = useState<ScanAlertTicket[]>(getScanAlertTickets());
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // ক্লাউড অবস্থা
  const [cloudSignedIn, setCloudSignedIn] = useState<boolean>(false);
  const [cloudPassword, setCloudPassword] = useState<string>('');
  const [cloudError, setCloudError] = useState<string | null>(null);
  const [fromCache, setFromCache] = useState<boolean>(false);
  const [hasPending, setHasPending] = useState<boolean>(false);
  const [countdown, setCountdown] = useState<number>(0);
  const [alarmCount, setAlarmCount] = useState<number | null>(null);
  const prevTicketCount = useRef<number>(-1);

  const cloudActive = cloudEnabled && cloudSignedIn;

  // এডমিন সাইন-ইন অবস্থা (অফলাইনেও আগের সেশন ধরে রাখে)
  useEffect(() => {
    const unsub = onAdminAuthChange((signedIn) => {
      setCloudSignedIn(signedIn);
      if (signedIn) subscribeAdminTopic();
    });
    return () => unsub();
  }, []);

  // ক্লাউড থেকে লাইভ স্ক্যান টিকেট (অফলাইনে ক্যাশ থেকে, নেট আসলে সিঙ্ক)
  useEffect(() => {
    if (!cloudActive) return;
    const unsub = subscribeTickets(
      (list, meta) => {
        if (prevTicketCount.current >= 0 && list.length > prevTicketCount.current) {
          soundManager.playNotificationSound();
        }
        prevTicketCount.current = list.length;
        setTickets(list);
        setFromCache(meta.fromCache);
        setHasPending(meta.pending);
      },
      (code) => setCloudError(code)
    );
    return () => {
      if (unsub) unsub();
    };
  }, [cloudActive]);

  // ক্লাউড না থাকলে আগের লোকাল পদ্ধতি
  useEffect(() => {
    if (cloudActive) return;
    let bc: BroadcastChannel | null = null;
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        bc = new BroadcastChannel('siam_bhai_channel');
        bc.onmessage = (event) => {
          if (event.data?.type === 'NEW_SCAN_TICKET') {
            soundManager.playNotificationSound();
            setTickets(getScanAlertTickets());
          }
        };
      } catch {
        // ignore
      }
    }

    const interval = setInterval(() => {
      setTickets(getScanAlertTickets());
    }, 1500);

    return () => {
      if (bc) bc.close();
      clearInterval(interval);
    };
  }, [cloudActive]);

  // ব্রডকাস্টের ৩০ সেকেন্ড কাউন্টডাউন
  useEffect(() => {
    if (countdown <= 0) return;
    const t = setTimeout(() => setCountdown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [countdown]);

  // ফোনে কতটি অ্যালার্ম সেট আছে
  const refreshAlarmCount = async () => {
    setAlarmCount(await getScheduledAlarmCount());
  };
  useEffect(() => {
    if (isNativeApp()) refreshAlarmCount();
  }, []);

  const handleCloudSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setCloudError(null);
    const res = await adminSignIn(cloudPassword.trim());
    if (!res.ok) setCloudError(res.error || 'সাইন-ইন ব্যর্থ');
    else setCloudPassword('');
  };

  const handleTestAlarms = async () => {
    const ok = await scheduleTestAlarms();
    setSuccessNotice(
      ok
        ? 'টেস্ট অ্যালার্ম সেট! ১০ সেকেন্ড পরে ৩ বার "চালু" ও তারপর ১ বার "বন্ধ" বাজবে।'
        : 'টেস্ট করা যায়নি — নোটিফিকেশন পারমিশন দিন (শুধু APK-তে কাজ করে)।'
    );
    setTimeout(() => setSuccessNotice(null), 5000);
  };

  const handleReschedule = async () => {
    const res = await scheduleWifiAlarms();
    await refreshAlarmCount();
    setSuccessNotice(
      res.ok ? `সব অ্যালার্ম ঠিক আছে (${res.count}টি)।` : 'অ্যালার্ম সেট করা যায়নি — পারমিশন দিন।'
    );
    setTimeout(() => setSuccessNotice(null), 4000);
  };

  const handleBroadcastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = draftMessage.trim();
    if (!text) return;

    soundManager.playNotificationSound();

    if (cloudEnabled) {
      if (!cloudSignedIn) {
        setSuccessNotice('আগে নিচের "ক্লাউড সাইন-ইন" করুন, তারপর ব্রডকাস্ট করুন।');
        setTimeout(() => setSuccessNotice(null), 4000);
        return;
      }
      sendBroadcastToCloud(text);
      setCountdown(BROADCAST_DELAY_SECONDS);
      setCurrentMessage(text);
      setDraftMessage('');
      setSuccessNotice(
        `মেসেজ জমা হয়েছে। ${BROADCAST_DELAY_SECONDS} সেকেন্ড পর সব ফোনে একসাথে যাবে (ফোন অফলাইনে থাকলে নেট আসলে পৌঁছাবে)।`
      );
      setTimeout(() => setSuccessNotice(null), 6000);
      return;
    }

    // ক্লাউড সেট করা নেই — শুধু এই ফোনে
    saveAdminBroadcastMessage(text);
    setCurrentMessage(text);
    setDraftMessage('');
    setSuccessNotice('ক্লাউড সেট করা নেই, তাই মেসেজ শুধু এই ফোনে সেভ হয়েছে।');
    setTimeout(() => setSuccessNotice(null), 4000);
  };

  const handleResolveTicket = (ticketId: string) => {
    soundManager.playStepChime();
    markTicketResolved(ticketId);
    if (cloudActive) {
      resolveTicketInCloud(ticketId);
    } else {
      setTickets(getScanAlertTickets());
    }
  };

  const handleResetDefault = () => {
    soundManager.playTick();
    saveAdminBroadcastMessage(DEFAULT_5AM_MESSAGE);
    setCurrentMessage(DEFAULT_5AM_MESSAGE);
    setSuccessNotice('ডিফল্ট ভোর ৫:০০টার বার্তা সক্রিয় করা হয়েছে।');
    setTimeout(() => setSuccessNotice(null), 3000);
  };

  const pendingTickets = tickets.filter((t) => t.status === 'pending');

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-4 animate-fade-in font-mono">
      {/* Admin Top Header */}
      <div className="glass-card-glow rounded-3xl p-5 sm:p-6 border border-[#00ff66]/50 mb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-[#00ff66] animate-pulse"></span>
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#00ff66]">
              ROOT://SIAM_COMMAND_TERMINAL • ACCESS LEVEL 00
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white text-cyber-green font-sans flex items-center gap-2">
            <Terminal className="w-6 h-6 text-[#00ff66]" />
            <span>সিয়াম ভাই এডমিন টার্মিনাল</span>
          </h1>
          <p className="text-xs text-slate-300 mt-0.5 font-sans">
            সরাসরি ইউজারদের ডিভাইসে মেসেজ পাঠান এবং কানেক্টেড ডিভাইসের লাইভ স্ক্যান রিকোয়েস্ট ট্র্যাক করুন।
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onBackToUserView}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#030e17] hover:bg-[#061e30] text-slate-200 border border-[#00ff66]/30 text-xs font-semibold cursor-pointer transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5 text-[#00ff66]" />
            <span>ইউজার পোর্টাল</span>
          </button>
          <button
            type="button"
            onClick={onLogout}
            className="px-3 py-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-300 border border-rose-800 text-xs font-semibold cursor-pointer transition-colors"
          >
            লগআউট
          </button>
        </div>
      </div>

      {/* সিস্টেম অবস্থা: ক্লাউড + অ্যালার্ম */}
      <div className="glass-panel rounded-3xl p-4 border border-[#00ff66]/30 mb-5 space-y-3 text-xs font-sans">
        <div className="flex flex-wrap items-center gap-2">
          <span
            className={`px-2.5 py-1 rounded-full border font-bold text-[11px] ${
              !cloudEnabled
                ? 'bg-amber-950 text-amber-300 border-amber-700'
                : cloudSignedIn
                ? 'bg-[#011a10] text-[#00ff66] border-[#00ff66]/50'
                : 'bg-rose-950 text-rose-300 border-rose-700'
            }`}
          >
            {!cloudEnabled
              ? 'ক্লাউড: সেট করা নেই (শুধু এই ফোনে)'
              : cloudSignedIn
              ? 'ক্লাউড: সংযুক্ত ✓'
              : 'ক্লাউড: সাইন-ইন করা হয়নি'}
          </span>
          {cloudActive && fromCache && (
            <span className="px-2.5 py-1 rounded-full border border-amber-700 bg-amber-950 text-amber-300 text-[11px]">
              অফলাইন — সংরক্ষিত তথ্য দেখাচ্ছে, নেট আসলে নতুন স্ক্যান আসবে
            </span>
          )}
          {cloudActive && hasPending && (
            <span className="px-2.5 py-1 rounded-full border border-cyan-700 bg-cyan-950 text-cyan-300 text-[11px]">
              কিছু পরিবর্তন নেট আসলে পাঠানো হবে
            </span>
          )}
        </div>

        {cloudEnabled && !cloudSignedIn && (
          <form onSubmit={handleCloudSignIn} className="flex flex-col sm:flex-row gap-2">
            <input
              type="password"
              value={cloudPassword}
              onChange={(e) => setCloudPassword(e.target.value)}
              placeholder="ক্লাউড সাইন-ইন পাসওয়ার্ড"
              className="flex-1 p-2.5 bg-[#020b12] border border-[#00ff66]/30 rounded-xl text-[#00ff66] placeholder-slate-600 text-xs outline-none focus:border-[#00ff66]"
            />
            <button
              type="submit"
              className="px-4 py-2.5 rounded-xl bg-[#00ff66] text-black font-black text-xs cursor-pointer"
            >
              ক্লাউড সাইন-ইন
            </button>
          </form>
        )}
        {cloudError && <p className="text-rose-300">{cloudError}</p>}

        {isNativeApp() && (
          <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#00ff66]/15">
            <span className="text-slate-300">
              ফোনে সেট অ্যালার্ম: <strong className="text-white">{alarmCount ?? '...'}</strong>টি
              (ভোর ৫টা ×১০ ও বিকেল ৫টা, শুক্রবার বাদ — মোট ৬৬টি হওয়ার কথা)
            </span>
            <button
              type="button"
              onClick={handleReschedule}
              className="px-3 py-1.5 rounded-lg bg-[#030e17] border border-slate-700 text-slate-200 cursor-pointer"
            >
              আবার সেট করুন
            </button>
            <button
              type="button"
              onClick={handleTestAlarms}
              className="px-3 py-1.5 rounded-lg bg-[#030e17] border border-[#00ff66]/40 text-[#00ff66] cursor-pointer"
            >
              অ্যালার্ম টেস্ট
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
        {/* Left: Broadcast Messenger */}
        <div className="md:col-span-7 glass-panel rounded-3xl p-5 border border-[#00ff66]/30 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2 font-sans">
              <Send className="w-4 h-4 text-[#00ff66]" />
              <span>ইউজারদের ফোনে মেসেজ পাঠান (Broadcast)</span>
            </h2>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#011a10] text-[#00ff66] border border-[#00ff66]/50">
              অফলাইনেও যাবে
            </span>
          </div>

          {/* Current Message */}
          <div className="p-3.5 rounded-2xl bg-[#020b12] border border-[#00ff66]/40 text-xs">
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="text-[#00ff66] font-semibold flex items-center gap-1">
                <Bell className="w-3.5 h-3.5 text-[#00ff66]" /> বর্তমানে ডিভাইসে যা পাঠানো হচ্ছে:
              </span>
              <button
                type="button"
                onClick={handleResetDefault}
                className="text-[10px] text-slate-400 hover:text-[#00ff66] underline cursor-pointer"
              >
                ডিফল্ট সেট
              </button>
            </div>
            <p className="text-xs sm:text-sm font-bold text-white leading-relaxed font-sans">
              “{currentMessage}”
            </p>
          </div>

          {/* Message Form */}
          <form onSubmit={handleBroadcastSubmit} className="space-y-3">
            <div>
              <label htmlFor="admin-msg-input" className="block text-xs font-bold text-[#00ff66] mb-1 uppercase tracking-wider">
                {'>'} নতুন সাইবার বার্তা ইনপুট:
              </label>
              <textarea
                id="admin-msg-input"
                rows={3}
                value={draftMessage}
                onChange={(e) => setDraftMessage(e.target.value)}
                placeholder="সিয়াম ভাই: ইউজারদের জন্য জরুরি নির্দেশনা বা ওয়াইফাই নোটিশ লিখুন..."
                className="w-full p-3 bg-[#020b12] border border-[#00ff66]/30 rounded-xl text-[#00ff66] placeholder-slate-600 text-xs sm:text-sm outline-none focus:border-[#00ff66] focus:ring-2 focus:ring-[#00ff66]/30 font-sans"
              />
            </div>

            {/* Quick Templates */}
            <div>
              <span className="text-[10px] text-slate-400 block mb-1">[QUICK_TEMPLATES]:</span>
              <div className="flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setDraftMessage('সিয়াম ভাই free wifi নেট চালু করা হয়েছে ভোর চারটা থেকে বিকেল পাঁচটা পরযন্ত')}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-[#030e17] hover:bg-[#061e30] text-slate-300 border border-slate-700 cursor-pointer font-sans"
                >
                  wifi চালু হয়েছে
                </button>
                <button
                  type="button"
                  onClick={() => setDraftMessage('সিয়াম ভাই: আপনার ওয়াইফাই সমস্যার সমাধান সম্পন্ন হয়েছে। ফুল স্পিড উপভোগ করুন।')}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-[#030e17] hover:bg-[#061e30] text-slate-300 border border-slate-700 cursor-pointer font-sans"
                >
                  সমস্যার সমাধান সম্পন্ন
                </button>
              </div>
            </div>

            {successNotice && (
              <div className="p-2.5 bg-[#011a10] border border-[#00ff66]/60 rounded-xl text-[#00ff66] text-xs font-medium animate-fade-in flex items-center gap-2">
                <CheckCircle className="w-4 h-4 shrink-0 text-[#00ff66]" />
                <span className="font-sans">{successNotice}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={!draftMessage.trim()}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#00ff66] via-[#00f0ff] to-[#00ff66] hover:from-[#22c55e] hover:to-[#06b6d4] text-slate-950 font-black text-xs sm:text-sm shadow-md shadow-[#00ff66]/25 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-all uppercase tracking-wider"
            >
              <Send className="w-4 h-4" />
              <span>
                {countdown > 0
                  ? `সব ফোনে যাচ্ছে... ${countdown} সেকেন্ড`
                  : 'সব ফোনে ব্রডকাস্ট করুন (BROADCAST)'}
              </span>
            </button>
          </form>
        </div>

        {/* Right: Inbound Scan Requests with User Device Name */}
        <div className="md:col-span-5 glass-panel rounded-3xl p-5 border border-[#00ff66]/30 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2 font-sans">
                <Smartphone className="w-4 h-4 text-[#00f0ff]" />
                <span>ইনকামিং ডিভাইস স্ক্যান অ্যালার্ট</span>
              </h2>
              {pendingTickets.length > 0 ? (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-950 text-rose-300 border border-rose-700 font-bold animate-pulse">
                  {pendingTickets.length} নতুন স্ক্যান
                </span>
              ) : (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#011a10] text-[#00ff66] border border-[#00ff66]/50">
                  ALL_CLEAR ✓
                </span>
              )}
            </div>

            {/* List of Scan Tickets */}
            <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
              {tickets.length === 0 ? (
                <div className="text-center py-12 text-slate-500 text-xs">
                  এখনও কোনো স্ক্যান রিকোয়েস্ট আসেনি
                </div>
              ) : (
                tickets.map((t) => (
                  <div
                    key={t.id}
                    className={`p-3 rounded-xl border text-xs transition-all ${
                      t.status === 'pending'
                        ? 'bg-[#020e17] border-[#00ff66]/60 shadow-md shadow-[#00ff66]/10'
                        : 'bg-black/40 border-slate-800 opacity-60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono font-bold text-white">{t.id}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{t.timestamp}</span>
                    </div>

                    <div className="flex items-center gap-1.5 text-[#00ff66] font-bold text-xs mb-1">
                      <Smartphone className="w-3.5 h-3.5 text-[#00f0ff]" />
                      <span>ডিভাইস: <strong className="text-white font-mono">{t.deviceName || t.userDevice}</strong></span>
                    </div>

                    <div className="p-2 rounded-lg bg-black/60 border border-slate-800 text-[10px] text-slate-400 mb-2 font-sans">
                      🔔 {t.phoneNotificationText}
                    </div>

                    {t.status === 'pending' && (
                      <button
                        type="button"
                        onClick={() => handleResolveTicket(t.id)}
                        className="w-full py-1.5 rounded-lg bg-[#00ff66] hover:bg-[#22c55e] text-black font-black text-[11px] transition-colors cursor-pointer uppercase tracking-wider"
                      >
                        সমস্যা সমাধান মার্ক করুন
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="pt-3 text-center text-[10px] text-slate-500 border-t border-[#00ff66]/20 mt-3 font-mono">
            CYBER_PULSE: SIAM_MESH_SYNC // ACTIVE
          </div>
        </div>
      </div>
    </div>
  );
};

