import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Volume2,
  VolumeX,
  Clock,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Terminal,
  Cpu,
  Wifi,
  ShieldCheck,
  Smile,
  Award,
  Anchor,
  Share2,
  Crown,
  Flame,
  Radio,
} from 'lucide-react';
import { PRAISE_STEPS } from '../utils/rules';
import { soundManager } from '../utils/audio';

// Cyberpunk Hacker Artworks for all 10 steps
const CYBER_ARTWORKS: Record<number, React.ReactNode> = {
  1: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#021810] via-[#063321] to-[#01140c] border-2 border-[#00ff66] flex items-center justify-center shadow-xl shadow-[#00ff66]/25 ring-4 ring-[#00ff66]/20 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,255,102,0.25)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <Sparkles className="w-14 h-14 text-[#00ff66] mx-auto drop-shadow-[0_0_12px_#00ff66]" />
        <span className="text-[9px] font-mono text-[#00f0ff] font-bold block mt-1 tracking-widest">
          HUMANITY_CORE
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#00ff66]/40">0x01_CHARITY</div>
    </div>
  ),
  2: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#02141c] via-[#052b3d] to-[#011218] border-2 border-[#00f0ff] flex items-center justify-center shadow-xl shadow-[#00f0ff]/25 ring-4 ring-[#00f0ff]/20 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,240,255,0.25)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <Cpu className="w-14 h-14 text-[#00f0ff] mx-auto drop-shadow-[0_0_12px_#00f0ff]" />
        <span className="text-[9px] font-mono text-[#00ff66] font-bold block mt-1 tracking-widest">
          QUANTUM_CPU
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#00f0ff]/40">0x02_GENIUS</div>
    </div>
  ),
  3: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#021814] via-[#06382c] to-[#01140e] border-2 border-[#10b981] flex items-center justify-center shadow-xl shadow-[#10b981]/25 ring-4 ring-[#10b981]/20 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(16,185,129,0.25)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <Wifi className="w-14 h-14 text-[#10b981] mx-auto drop-shadow-[0_0_12px_#10b981]" />
        <span className="text-[9px] font-mono text-[#00f0ff] font-bold block mt-1 tracking-widest">
          5G_BEACON
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#10b981]/40">0x03_FREE_NET</div>
    </div>
  ),
  4: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#1a1402] via-[#382b04] to-[#120e01] border-2 border-[#f59e0b] flex items-center justify-center shadow-xl shadow-[#f59e0b]/25 ring-4 ring-[#f59e0b]/20 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(245,158,11,0.25)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <ShieldCheck className="w-14 h-14 text-[#f59e0b] mx-auto drop-shadow-[0_0_12px_#f59e0b]" />
        <span className="text-[9px] font-mono text-[#00ff66] font-bold block mt-1 tracking-widest">
          FIREWALL_AEGIS
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#f59e0b]/40">0x04_DEFENSE</div>
    </div>
  ),
  5: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#021810] via-[#053020] to-[#01140d] border-2 border-[#00ff66] flex items-center justify-center shadow-xl shadow-[#00ff66]/25 ring-4 ring-[#00ff66]/20 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,255,102,0.25)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <Radio className="w-14 h-14 text-[#00ff66] mx-auto drop-shadow-[0_0_12px_#00ff66]" />
        <span className="text-[9px] font-mono text-[#00f0ff] font-bold block mt-1 tracking-widest">
          MENTOR_PULSE
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#00ff66]/40">0x05_GUIDE</div>
    </div>
  ),
  6: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#021814] via-[#073d31] to-[#011610] border-2 border-[#10b981] flex items-center justify-center shadow-xl shadow-[#10b981]/25 ring-4 ring-[#10b981]/20 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(16,185,129,0.25)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <Smile className="w-14 h-14 text-[#10b981] mx-auto drop-shadow-[0_0_12px_#10b981]" />
        <span className="text-[9px] font-mono text-[#00f0ff] font-bold block mt-1 tracking-widest">
          HOLOGRAM_GRACE
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#10b981]/40">0x06_POLITE</div>
    </div>
  ),
  7: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#1c1802] via-[#3d3305] to-[#141101] border-2 border-[#eab308] flex items-center justify-center shadow-xl shadow-[#eab308]/25 ring-4 ring-[#eab308]/20 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(234,179,8,0.25)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <Award className="w-14 h-14 text-[#eab308] mx-auto drop-shadow-[0_0_12px_#eab308]" />
        <span className="text-[9px] font-mono text-[#00ff66] font-bold block mt-1 tracking-widest">
          CRYPTO_INTEGRITY
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#eab308]/40">0x07_TRUTH</div>
    </div>
  ),
  8: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#021816] via-[#053833] to-[#011412] border-2 border-[#00f0ff] flex items-center justify-center shadow-xl shadow-[#00f0ff]/25 ring-4 ring-[#00f0ff]/20 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(0,240,255,0.25)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <Anchor className="w-14 h-14 text-[#00f0ff] mx-auto drop-shadow-[0_0_12px_#00f0ff]" />
        <span className="text-[9px] font-mono text-[#00ff66] font-bold block mt-1 tracking-widest">
          QUANTUM_ANCHOR
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#00f0ff]/40">0x08_SECURE</div>
    </div>
  ),
  9: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#0c081c] via-[#1f1345] to-[#070412] border-2 border-[#818cf8] flex items-center justify-center shadow-xl shadow-[#818cf8]/25 ring-4 ring-[#818cf8]/20 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(129,140,248,0.25)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <Share2 className="w-14 h-14 text-[#818cf8] mx-auto drop-shadow-[0_0_12px_#818cf8]" />
        <span className="text-[9px] font-mono text-[#00f0ff] font-bold block mt-1 tracking-widest">
          P2P_MESH_SYNDICATE
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#818cf8]/40">0x09_BROTHER</div>
    </div>
  ),
  10: (
    <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-[#1c1202] via-[#452b05] to-[#140b01] border-2 border-[#fbbf24] flex items-center justify-center shadow-2xl shadow-[#fbbf24]/35 ring-4 ring-[#fbbf24]/30 animate-float overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(251,191,36,0.35)_0%,_transparent_70%)]"></div>
      <div className="text-center relative z-10">
        <Crown className="w-14 h-14 text-[#fbbf24] mx-auto drop-shadow-[0_0_15px_#fbbf24]" />
        <span className="text-[9px] font-mono text-[#00ff66] font-black block mt-1 tracking-widest">
          ROOT_OVERLORD
        </span>
      </div>
      <div className="absolute top-1 left-2 text-[8px] font-mono text-[#fbbf24]/50">0x10_LEGEND</div>
    </div>
  ),
};

interface StepPraisesProps {
  currentStepIndex: number;
  onStepChange: (index: number) => void;
  onOpenDeviceNameModal: () => void;
}

export const StepPraises: React.FC<StepPraisesProps> = ({
  currentStepIndex,
  onStepChange,
  onOpenDeviceNameModal,
}) => {
  const step = PRAISE_STEPS[currentStepIndex];
  const [secondsRemaining, setSecondsRemaining] = useState<number>(3);
  const [isVoicePlaying, setIsVoicePlaying] = useState<boolean>(false);
  const [autoVoice, setAutoVoice] = useState<boolean>(true);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize 3-second mandatory waiting timer whenever step changes
  useEffect(() => {
    setSecondsRemaining(3);
    soundManager.playTick();

    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    const startTime = Date.now();
    timerRef.current = setInterval(() => {
      const elapsed = Math.floor((Date.now() - startTime) / 1000);
      const remaining = Math.max(0, 3 - elapsed);
      setSecondsRemaining(remaining);

      if (remaining > 0) {
        soundManager.playTick();
      }

      if (remaining === 0) {
        if (timerRef.current) clearInterval(timerRef.current);
        soundManager.playStepChime();
      }
    }, 1000);

    // Auto-voice narration
    if (autoVoice) {
      soundManager.speak(
        step.voiceText,
        () => setIsVoicePlaying(true),
        () => setIsVoicePlaying(false)
      );
    } else {
      soundManager.stopSpeech();
      setIsVoicePlaying(false);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      soundManager.stopSpeech();
    };
  }, [currentStepIndex, step.voiceText, autoVoice]);

  const toggleVoice = () => {
    if (isVoicePlaying) {
      soundManager.stopSpeech();
      setIsVoicePlaying(false);
    } else {
      soundManager.speak(
        step.voiceText,
        () => setIsVoicePlaying(true),
        () => setIsVoicePlaying(false)
      );
    }
  };

  const handleNext = () => {
    if (secondsRemaining > 0) return;
    soundManager.stopSpeech();
    if (currentStepIndex < PRAISE_STEPS.length - 1) {
      onStepChange(currentStepIndex + 1);
    } else {
      // 10th step completed -> open Device Name modal
      onOpenDeviceNameModal();
    }
  };

  const handlePrev = () => {
    soundManager.stopSpeech();
    if (currentStepIndex > 0) {
      onStepChange(currentStepIndex - 1);
    }
  };

  const isFinishedWaiting = secondsRemaining === 0;
  const isFinalStep = currentStepIndex === PRAISE_STEPS.length - 1;
  const timerProgress = ((3 - secondsRemaining) / 3) * 100;

  return (
    <div className="w-full max-w-3xl mx-auto px-4 py-4 relative z-10">
      {/* Top Cyber 10-Step Progress Track */}
      <div className="mb-5 glass-panel rounded-2xl p-4 border border-[#00ff66]/25">
        <div className="flex items-center justify-between text-xs font-mono text-slate-300 mb-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#00ff66] animate-ping"></span>
            <span className="font-bold text-[#00ff66] tracking-wider uppercase">
              SIAM_SECURITY_PROTOCOL • DECRYPTION STAGE
            </span>
          </div>
          <div className="font-mono bg-[#030d12] px-2.5 py-1 rounded-lg text-[#00f0ff] font-bold border border-[#00f0ff]/30">
            PHASE {currentStepIndex + 1} / 10 ({Math.round(((currentStepIndex + 1) / 10) * 100)}%)
          </div>
        </div>

        {/* 10 Step Matrix Bars (Cannot be skipped!) */}
        <div className="grid grid-cols-10 gap-1.5 sm:gap-2">
          {PRAISE_STEPS.map((s, idx) => {
            const isCompleted = idx < currentStepIndex;
            const isCurrent = idx === currentStepIndex;
            return (
              <div
                key={s.id}
                className={`h-2 sm:h-2.5 rounded-full transition-all duration-300 ${
                  isCurrent
                    ? 'bg-gradient-to-r from-[#00ff66] to-[#00f0ff] shadow-md shadow-[#00ff66]/50 scale-105 ring-2 ring-[#00ff66]'
                    : isCompleted
                    ? 'bg-[#00ff66]/70'
                    : 'bg-slate-800/60 opacity-40'
                }`}
              />
            );
          })}
        </div>
      </div>

      {/* Main Step Praise Card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={step.id}
          initial={{ opacity: 0, y: 15, scale: 0.98 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -15, scale: 0.98 }}
          transition={{ duration: 0.3, ease: 'easeOut' }}
          className="glass-card-glow rounded-3xl p-6 sm:p-8 border border-[#00ff66]/30 shadow-2xl relative overflow-hidden font-mono"
        >
          {/* Top Status Line */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-6 relative z-10">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#011a10] border border-[#00ff66]/50 text-[#00ff66] shadow">
              <Terminal className="w-3.5 h-3.5 text-[#00f0ff]" />
              {step.badge}
            </span>

            {/* Cyber Voice Control */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setAutoVoice(!autoVoice)}
                className={`text-[11px] px-2.5 py-1 rounded-lg border font-mono transition-all cursor-pointer ${
                  autoVoice
                    ? 'bg-[#00ff66]/15 border-[#00ff66] text-[#00ff66]'
                    : 'bg-slate-900 border-slate-700 text-slate-400'
                }`}
              >
                AI_VOICE: {autoVoice ? 'ACTIVE' : 'MUTED'}
              </button>

              <button
                type="button"
                onClick={toggleVoice}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-all cursor-pointer ${
                  isVoicePlaying
                    ? 'bg-rose-500/20 border border-rose-500/50 text-rose-300 animate-pulse'
                    : 'bg-[#00ff66]/15 hover:bg-[#00ff66]/25 border border-[#00ff66]/40 text-[#00ff66]'
                }`}
              >
                {isVoicePlaying ? (
                  <>
                    <VolumeX className="w-3.5 h-3.5" />
                    <span>ভয়েস থামান</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>ভয়েস শুনুন</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Central Artwork & Praise Text */}
          <div className="flex flex-col md:flex-row items-center md:items-start gap-6 mb-7 relative z-10">
            <div className="shrink-0 relative">
              {CYBER_ARTWORKS[step.id]}
              <div className="absolute -bottom-2 -right-1 bg-black border border-[#00ff66] text-[#00ff66] px-2 py-0.5 rounded-full text-[10px] font-mono font-bold shadow">
                SEC_0{step.id}
              </div>
            </div>

            <div className="flex-1 text-center md:text-left">
              <h2 className="text-xl sm:text-2xl font-black text-white mb-2 tracking-tight text-cyber-green font-sans">
                {step.title}
              </h2>
              <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-3 font-sans">
                {step.description}
              </p>
              <div className="p-3.5 rounded-2xl bg-[#020b12] border border-[#00ff66]/30 text-[#00f0ff] text-xs sm:text-sm italic font-medium font-sans">
                <Flame className="w-3.5 h-3.5 text-[#00ff66] inline mr-1.5 shrink-0" />
                {step.praiseQuote}
              </div>
            </div>
          </div>

          {/* 3-Second Mandatory Decryption Timer */}
          <div className="p-3.5 rounded-2xl bg-[#010a0e] border border-[#00ff66]/25 mb-5 relative z-10">
            <div className="flex items-center justify-between text-xs mb-1.5 font-mono">
              <div className="flex items-center gap-1.5 text-slate-300 font-semibold">
                <Clock className="w-3.5 h-3.5 text-[#00ff66]" />
                <span>
                  {isFinishedWaiting
                    ? '[SECURITY PROTOCOL UNLOCKED • ACCESS GRANTED]'
                    : `ENCRYPTION SYNC: ${secondsRemaining}s REMAINING...`}
                </span>
              </div>
              <span className={`font-mono text-[11px] font-bold px-2 py-0.5 rounded ${
                isFinishedWaiting ? 'bg-[#00ff66]/20 text-[#00ff66] border border-[#00ff66]/50' : 'bg-amber-950 text-amber-300 border border-amber-700'
              }`}>
                {isFinishedWaiting ? 'UNLOCKED ✓' : `${secondsRemaining}s`}
              </span>
            </div>

            <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-[#00ff66]/20">
              <div
                className={`h-full transition-all duration-300 ease-linear ${
                  isFinishedWaiting
                    ? 'bg-gradient-to-r from-[#00ff66] to-[#00f0ff]'
                    : 'bg-gradient-to-r from-amber-500 to-[#00ff66]'
                }`}
                style={{ width: `${timerProgress}%` }}
              />
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between gap-3 relative z-10 font-mono">
            <button
              type="button"
              onClick={handlePrev}
              disabled={currentStepIndex === 0}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-900 disabled:opacity-30 disabled:pointer-events-none transition-all text-xs font-semibold cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>পূর্ববর্তী ধাপ</span>
            </button>

            <button
              type="button"
              onClick={handleNext}
              disabled={!isFinishedWaiting}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-black text-xs sm:text-sm transition-all transform shadow-lg cursor-pointer ${
                isFinishedWaiting
                  ? isFinalStep
                    ? 'bg-gradient-to-r from-[#00ff66] via-[#00f0ff] to-[#00ff66] text-black font-black scale-102 hover:scale-105 shadow-[#00ff66]/40'
                    : 'bg-gradient-to-r from-[#00ff66] to-[#00f0ff] hover:from-[#22c55e] hover:to-[#06b6d4] text-black shadow-[#00ff66]/30 hover:-translate-y-0.5'
                  : 'bg-slate-900 text-slate-600 border border-slate-800 cursor-not-allowed opacity-60'
              }`}
            >
              {isFinishedWaiting ? (
                isFinalStep ? (
                  <>
                    <span>১০টি ধাপ সম্পন্ন! ডিভাইসের নাম দিন</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                ) : (
                  <>
                    <span>পরবর্তী ধাপে যান ({currentStepIndex + 2}/১০)</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )
              ) : (
                <>
                  <Clock className="w-3.5 h-3.5 animate-spin text-[#00ff66]" />
                  <span>অপেক্ষা করুন ({secondsRemaining}s)...</span>
                </>
              )}
            </button>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
