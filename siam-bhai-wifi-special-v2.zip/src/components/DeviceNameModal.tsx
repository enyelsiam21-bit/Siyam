import React, { useState } from 'react';
import { Smartphone, CheckCircle, ArrowRight, ShieldCheck, Terminal, Cpu } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface DeviceNameModalProps {
  isOpen: boolean;
  onSubmitDeviceName: (deviceName: string) => void;
}

export const DeviceNameModal: React.FC<DeviceNameModalProps> = ({ isOpen, onSubmitDeviceName }) => {
  const [deviceName, setDeviceName] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deviceName.trim()) {
      setError('[ERROR]: ডিভাইসের নাম খালি রাখা যাবে না! অনুগ্রহ করে নাম দিন।');
      return;
    }
    soundManager.playStepChime();
    onSubmitDeviceName(deviceName.trim());
  };

  const handleQuickPick = (name: string) => {
    setDeviceName(name);
    setError(null);
    soundManager.playTick();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in font-mono">
      <div className="w-full max-w-md glass-card-glow rounded-3xl p-6 sm:p-8 border border-[#00ff66]/50 shadow-2xl relative overflow-hidden">
        {/* Terminal Header */}
        <div className="flex items-center justify-between text-[10px] text-[#00ff66] mb-4 border-b border-[#00ff66]/20 pb-2">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-[#00ff66] animate-ping"></span>
            ROOT://AUTH_PROTOCOL
          </span>
          <span className="text-[#00f0ff] font-bold">10/10 DECRYPTED ✓</span>
        </div>

        {/* Central Terminal Icon */}
        <div className="flex justify-center mb-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#021810] via-[#053020] to-[#01140d] border border-[#00ff66] flex items-center justify-center shadow-lg shadow-[#00ff66]/30 ring-2 ring-[#00ff66]/40 animate-float">
            <Smartphone className="w-8 h-8 text-[#00ff66]" />
          </div>
        </div>

        <div className="text-center mb-5">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-bold bg-[#011a10] text-[#00ff66] border border-[#00ff66]/50 mb-2">
            <CheckCircle className="w-3.5 h-3.5 text-[#00ff66]" /> ১০টি ধাপ সফলভাবে ডিক্রিপ্ট হয়েছে!
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-white text-cyber-green font-sans">
            আপনার ডিভাইসের নাম লিখুন
          </h2>
          <p className="text-xs text-slate-300 mt-1 font-sans">
            WiFi স্ক্যান শুরু করতে এবং সিয়াম ভাইয়ের নেটওয়ার্কে যুক্ত হতে আপনার ডিভাইসের নাম দিন।
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="device-name-input" className="block text-xs font-bold text-[#00ff66] mb-1.5 uppercase tracking-wider">
              {'>'} DEVICE_HOSTNAME / নাম:
            </label>
            <input
              id="device-name-input"
              type="text"
              value={deviceName}
              onChange={(e) => {
                setDeviceName(e.target.value);
                if (error) setError(null);
              }}
              placeholder="যেমন: Samsung S24 Ultra, iPhone 15, Redmi Note..."
              className="w-full px-4 py-3 bg-[#020b12] border border-[#00ff66]/50 focus:border-[#00ff66] focus:ring-2 focus:ring-[#00ff66]/30 rounded-xl text-[#00ff66] placeholder-slate-600 text-xs sm:text-sm outline-none transition-all font-mono tracking-wide"
              autoFocus
            />
          </div>

          {/* Quick Hardware Pick */}
          <div>
            <span className="text-[10px] text-slate-400 block mb-1.5">[QUICK_PRESETS]:</span>
            <div className="flex flex-wrap gap-1.5">
              {['Samsung Galaxy 5G', 'iPhone 15 Pro', 'Redmi Note Cyber', 'Vivo / Oppo 5G', 'Realme Master'].map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => handleQuickPick(item)}
                  className="text-[11px] px-2.5 py-1 rounded-lg bg-[#030e17] hover:bg-[#061e30] text-slate-300 border border-slate-700 hover:border-[#00ff66]/60 transition-colors cursor-pointer font-mono"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          {error && (
            <div className="p-2.5 bg-rose-950/80 border border-rose-500/50 rounded-xl text-rose-300 text-xs text-center font-mono animate-shake">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="w-full py-3.5 px-4 bg-gradient-to-r from-[#00ff66] via-[#00f0ff] to-[#00ff66] hover:from-[#22c55e] hover:to-[#06b6d4] text-slate-950 font-black rounded-xl shadow-lg shadow-[#00ff66]/30 flex items-center justify-center gap-2 text-xs sm:text-sm tracking-wider uppercase transition-all cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <span>ডিভাইস ভেরিফাই ও স্ক্যান শুরু করুন</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="mt-4 pt-3 border-t border-[#00ff66]/20 text-center text-[10px] text-slate-400 flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 text-[#00ff66]" />
          <span>ডিভাইস শনাক্তকরণ সরাসরি সিয়াম ভাইয়ের এডমিন টার্মিনালে সংরক্ষিত হবে</span>
        </div>
      </div>
    </div>
  );
};

