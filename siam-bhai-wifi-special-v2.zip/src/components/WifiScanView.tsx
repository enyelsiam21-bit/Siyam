import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  Wifi,
  Radio,
  CheckCircle,
  Clock,
  Smartphone,
  Volume2,
  ShieldCheck,
  Zap,
  Terminal,
  Activity,
} from 'lucide-react';
import { RESOLUTION_MESSAGE, recordNewScanTicket } from '../utils/rules';
import { soundManager } from '../utils/audio';
import { pushScanTicketToCloud } from '../utils/cloud';
import { getWifiState, describeWifiState } from '../utils/schedule';

interface WifiScanViewProps {
  deviceName: string;
  onResetSteps: () => void;
}

export const WifiScanView: React.FC<WifiScanViewProps> = ({
  deviceName,
  onResetSteps,
}) => {
  const [isScanning, setIsScanning] = useState<boolean>(true);
  const [scanProgress, setScanProgress] = useState<number>(0);
  const [twoHoursRemaining, setTwoHoursRemaining] = useState<number>(7200);
  const [ticketId, setTicketId] = useState<string>('');
  const scanTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    startRadarScan();
    return () => {
      if (scanTimerRef.current) clearInterval(scanTimerRef.current);
      soundManager.stopSpeech();
    };
  }, []);

  // 2-hour countdown timer
  useEffect(() => {
    if (!isScanning) {
      const timer = setInterval(() => {
        setTwoHoursRemaining((prev) => Math.max(0, prev - 1));
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isScanning]);

  const startRadarScan = () => {
    setIsScanning(true);
    setScanProgress(0);
    soundManager.playRadarPing();

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsScanning(false);

          // Dispatch scan alert with exact user device name to Admin Panel
          const ticket = recordNewScanTicket(deviceName || 'CYBER_DEVICE_NODE');
          setTicketId(ticket.id);
          // এডমিন প্যানেলে পাঠায় — অফলাইনে হলে ফোনে জমা থাকে, নেট আসলে নিজে থেকে যায়
          pushScanTicketToCloud(ticket);

          // Confetti celebration
          confetti({
            particleCount: 100,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#00ff66', '#00f0ff', '#ffffff', '#10b981'],
          });

          soundManager.playStepChime();

          // Cyber AI voice narration
          const closedNote =
            getWifiState(new Date()) === 'open' ? '' : `${describeWifiState(new Date())}। `;
          soundManager.speak(
            `${closedNote}দুই ঘণ্টার মধ্যে আপনার সমস্যাটি সমাধান করা হচ্ছে। ডিভাইস ${deviceName} সিয়াম ভাইয়ের নেটওয়ার্কে সফলভাবে সংযুক্ত হয়েছে।`
          );
          return 100;
        }
        return prev + 15;
      });
    }, 130);

    scanTimerRef.current = interval;
  };

  const formatCountdown = (totalSec: number) => {
    const hours = Math.floor(totalSec / 3600);
    const minutes = Math.floor((totalSec % 3600) / 60);
    const seconds = totalSec % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  };

  return (
    <div className="w-full max-w-lg mx-auto px-4 py-4 animate-fade-in font-mono">
      <div className="glass-card-glow rounded-3xl p-6 sm:p-8 border border-[#00ff66]/40 shadow-2xl text-center relative overflow-hidden">
        {/* Ambient Glowing Orbs */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-[#00ff66]/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Top Terminal Status */}
        <div className="flex items-center justify-between text-[10px] text-[#00ff66] mb-4 border-b border-[#00ff66]/20 pb-2">
          <span className="flex items-center gap-1.5">
            <Radio className="w-3 h-3 text-[#00ff66] animate-pulse" />
            FREQ: 5.8GHZ // ULTRA_WIDEBAND
          </span>
          <span className="text-[#00f0ff] font-bold">RADAR_ACTIVE</span>
        </div>

        {/* Top Badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold bg-[#011a10] border border-[#00ff66]/50 text-[#00ff66] mb-3">
          <Activity className="w-3.5 h-3.5 text-[#00ff66] animate-pulse" />
          <span>সিয়াম ভাই সাইবার WiFi রাডার</span>
        </div>

        {/* Device Name Display */}
        <div className="flex items-center justify-center gap-1.5 text-xs text-slate-300 mb-4 bg-[#030e17] py-1.5 px-3 rounded-xl border border-[#00ff66]/30 w-fit mx-auto">
          <Smartphone className="w-3.5 h-3.5 text-[#00f0ff]" />
          <span>স্ক্যানরত ডিভাইস: <strong className="text-[#00ff66] font-mono">{deviceName || 'CYBER_CLIENT'}</strong></span>
        </div>

        {/* wifi সময়সূচি অবস্থা (শুক্রবার / সময়ের বাইরে হলে দেখায়) */}
        {getWifiState(new Date()) !== 'open' && (
          <div className="mb-3 p-2.5 rounded-xl bg-amber-950/80 border border-amber-600/50 text-amber-200 text-xs font-sans">
            {describeWifiState(new Date())}
          </div>
        )}

        {/* Futuristic Cyber Radar Animation */}
        <div className="relative w-48 h-48 sm:w-52 sm:h-52 mx-auto my-3 rounded-full border-2 border-[#00ff66]/40 flex items-center justify-center bg-[#01080e] shadow-[0_0_30px_rgba(0,255,102,0.15)]">
          <div className="absolute w-36 h-36 rounded-full border border-[#00ff66]/20"></div>
          <div className="absolute w-24 h-24 rounded-full border border-[#00f0ff]/30"></div>
          <div className="absolute w-12 h-12 rounded-full border border-[#00ff66]/40 bg-[#00ff66]/10"></div>

          {/* Crosshairs */}
          <div className="absolute w-full h-[1px] bg-[#00ff66]/20"></div>
          <div className="absolute h-full w-[1px] bg-[#00ff66]/20"></div>

          {/* Radar Sweep */}
          <div
            className={`absolute inset-0 rounded-full pointer-events-none ${
              isScanning ? 'animate-radar' : ''
            }`}
            style={{
              background:
                'conic-gradient(from 0deg at 50% 50%, rgba(0, 255, 102, 0.45) 0deg, rgba(0, 240, 255, 0.15) 45deg, rgba(0,0,0,0) 65deg)',
            }}
          ></div>

          <div className="w-8 h-8 rounded-full bg-[#00ff66] shadow-lg shadow-[#00ff66]/80 flex items-center justify-center z-10 animate-pulse">
            <Wifi className="w-4 h-4 text-black font-black" />
          </div>
        </div>

        {/* Dynamic Scan vs Completed State */}
        {isScanning ? (
          <div className="space-y-3 mt-4">
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center justify-center gap-2 font-mono">
              <Zap className="w-4 h-4 text-[#00ff66] animate-bounce" />
              <span>QUANTUM SCANNING CHANNELS...</span>
            </h2>
            <div className="w-56 mx-auto bg-slate-900 h-2.5 rounded-full overflow-hidden border border-[#00ff66]/30">
              <div
                className="h-full bg-gradient-to-r from-[#00ff66] via-[#00f0ff] to-[#00ff66] transition-all duration-150"
                style={{ width: `${scanProgress}%` }}
              />
            </div>
            <p className="text-xs text-slate-400 font-sans">ফ্রিকোয়েন্সি অ্যানালাইসিস ও সিগন্যাল অপটিমাইজেশন চলছে</p>
          </div>
        ) : (
          <div className="space-y-4 mt-4 animate-fade-in">
            {/* Resolution Card */}
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-[#011a10] via-[#021018] to-[#011a10] border border-[#00ff66]/60 text-left shadow-xl shadow-[#00ff66]/10">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#00ff66]/20 border border-[#00ff66]/50 flex items-center justify-center shrink-0 mt-0.5">
                  <CheckCircle className="w-6 h-6 text-[#00ff66] animate-pulse" />
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#00ff66] block">
                    অফিসিয়াল সমাধান নিশ্চয়তা
                  </span>
                  <h3 className="text-base sm:text-lg font-black text-white leading-snug font-sans text-cyber-green">
                    {RESOLUTION_MESSAGE}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 font-sans">
                    ডিভাইস <strong>{deviceName}</strong> সিয়াম ভাইয়ের সার্ভারে নিবন্ধিত হয়েছে।
                  </p>
                </div>
              </div>

              {/* 2-Hour Live Countdown */}
              <div className="mt-3.5 pt-3 border-t border-[#00ff66]/20 flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-slate-300">
                  <Clock className="w-3.5 h-3.5 text-[#00ff66]" />
                  <span>সমাধান বাকি: <strong className="font-mono text-[#00ff66] font-bold">{formatCountdown(twoHoursRemaining)}</strong></span>
                </div>
                <span className="font-mono text-[#00f0ff] font-bold bg-[#020b12] px-2.5 py-0.5 rounded border border-[#00f0ff]/40">
                  1200 Mbps (5G)
                </span>
              </div>
            </div>

            {/* Found Verified Network */}
            <div className="p-3 rounded-xl bg-[#020d14] border border-[#00ff66]/40 text-xs text-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wifi className="w-4 h-4 text-[#00ff66]" />
                <span className="font-bold text-white tracking-wide">🌟 SIAM-BHAI-FREE-WIFI-5G 🌟</span>
              </div>
              <span className="text-[#00ff66] font-bold bg-[#011a10] px-2 py-0.5 rounded border border-[#00ff66]/60">
                সংযুক্ত (100%)
              </span>
            </div>

            {/* Admin Phone Dispatch confirmation */}
            <div className="p-2.5 rounded-xl bg-black/60 border border-[#00ff66]/20 text-[11px] text-slate-400 flex items-center justify-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#00ff66]" />
              <span>টিকেট #{ticketId || 'TKT-991'} — সিয়াম ভাইয়ের এডমিন টার্মিনালে প্রেরিত</span>
            </div>

            {/* Actions */}
            <div className="pt-2 flex items-center justify-between text-xs text-slate-400 font-mono">
              <button
                type="button"
                onClick={onResetSteps}
                className="hover:text-[#00ff66] underline cursor-pointer"
              >
                ← ১০টি ধাপের শুনামে ফিরুন
              </button>

              <button
                type="button"
                onClick={() =>
                  soundManager.speak(
                    `দুই ঘণ্টার মধ্যে আপনার সমস্যাটি সমাধান করা হচ্ছে। ডিভাইস ${deviceName} প্রস্তুত।`
                  )
                }
                className="flex items-center gap-1 text-[#00f0ff] hover:text-[#00ff66] cursor-pointer"
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>ভয়েস আবার শুনুন</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

