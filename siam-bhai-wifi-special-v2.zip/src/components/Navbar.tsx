import React from 'react';
import { Wifi, LogOut, WifiOff, Terminal, Zap } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface NavbarProps {
  isOnline: boolean;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ isOnline, onLogout }) => {
  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b border-[#00ff66]/30 px-4 py-2.5 backdrop-blur-xl font-mono">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#021810] to-[#053020] border border-[#00ff66] flex items-center justify-center shadow-md shadow-[#00ff66]/20 text-[#00ff66] font-bold">
            <Zap className="w-5 h-5 fill-[#00ff66]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm sm:text-base text-white tracking-wide text-cyber-green flex items-center gap-1">
                <span>⚡</span>
                <span>SIYAM INFINITY NETWORK</span>
              </span>
              {!isOnline && (
                <span className="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-700">
                  <WifiOff className="w-2.5 h-2.5" /> OFFLINE_MODE
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Clean Logout */}
        <button
          type="button"
          onClick={() => {
            soundManager.playTick();
            onLogout();
          }}
          className="flex items-center gap-1.5 p-1.5 px-3 rounded-xl bg-[#030e17] hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-800 hover:border-rose-700 text-xs transition-colors cursor-pointer"
          title="লগআউট"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>লগআউট</span>
        </button>
      </div>
    </header>
  );
};

