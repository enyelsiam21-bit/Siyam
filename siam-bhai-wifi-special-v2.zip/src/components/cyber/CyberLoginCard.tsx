/**
 * CyberLoginCard.tsx
 * Hollywood Sci-Fi Hacker Command Center WiFi Interface
 * SIYAM X — CYBER EMPIRE
 */

import React, { useState, useEffect } from 'react';
import {
  Wifi,
  Eye,
  EyeOff,
  ShieldCheck,
  ShieldAlert,
  Terminal,
  Activity,
  Zap,
  Globe,
  Radio,
  RotateCcw,
  Sliders,
  ExternalLink,
} from 'lucide-react';
import { soundEngine } from './CyberSoundEngine';
import { validateLoginPassword, recordNewScanTicket } from '../../utils/rules';

interface CyberLoginCardProps {
  onAdminAccess: () => void;
  language: 'bn' | 'en';
  onOpenHelp: () => void;
  onOpenAbout: () => void;
}

export const CyberLoginCard: React.FC<CyberLoginCardProps> = ({
  onAdminAccess,
  language,
  onOpenHelp,
  onOpenAbout,
}) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authStepText, setAuthStepText] = useState('');
  const [errorNotice, setErrorNotice] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [deviceName, setDeviceName] = useState('CYBER_DEVICE_X');
  const [pingSpeed, setPingSpeed] = useState(1);
  const [liveBytes, setLiveBytes] = useState(128.4);

  // Auto-detect browser/OS device for realistic cyber HUD
  useEffect(() => {
    if (typeof navigator !== 'undefined') {
      const ua = navigator.userAgent;
      if (ua.includes('Android')) setDeviceName('ANDROID_CYBER_TERMINAL');
      else if (ua.includes('iPhone')) setDeviceName('IOS_QUANTUM_MOBILE');
      else if (ua.includes('Macintosh')) setDeviceName('MACOS_CORE_WORKSTATION');
      else if (ua.includes('Windows')) setDeviceName('WINDOWS_CYBER_NODE');
      else setDeviceName('HOLONET_RECEPTOR_01');
    }
  }, []);

  // Live byte throughput simulation when connected
  useEffect(() => {
    if (!isConnected) return;
    const interval = setInterval(() => {
      setLiveBytes((prev) => +(prev + (Math.random() * 2.4 - 1.1)).toFixed(1));
      setPingSpeed(Math.floor(1 + Math.random() * 3));
    }, 1200);
    return () => clearInterval(interval);
  }, [isConnected]);

  const handleToggleShowPassword = () => {
    soundEngine.playClick();
    setShowPassword((prev) => !prev);
  };

  const handleConnect = (e: React.FormEvent) => {
    e.preventDefault();
    soundEngine.playClick();
    soundEngine.playScanHum();

    if (!password.trim()) {
      soundEngine.playAccessDenied();
      setErrorNotice(
        language === 'bn'
          ? 'অনুগ্রহ করে পাসওয়ার্ড প্রদান করুন!'
          : 'ERROR: PASSCODE CANNOT BE NULL. ENTER CREDENTIALS.'
      );
      return;
    }

    setErrorNotice(null);
    setIsAuthenticating(true);
    soundEngine.speakConnecting();

    const handshakeSteps =
      language === 'bn'
        ? [
            'ধাপ ১: কোয়ান্টাম লিংক ইনিশিয়ালাইজ হচ্ছে...',
            'ধাপ ২: ২৫৬-বিট সাইবার এনক্রিপশন যাচাইকরণ...',
            'ধাপ ৩: সিয়ামের সিকিউর মেশ রাউটার যাচাই...',
            'ধাপ ৪: ৫.৮ GHz বিমফর্মিং তরঙ্গ সংযুক্ত হচ্ছে...',
          ]
        : [
            '[01/04] INITIALIZING QUANTUM HANDSHAKE...',
            '[02/04] VERIFYING 256-BIT ENCRYPTION SIGNATURE...',
            '[03/04] ROUTING VIA SIYAM X SECURE MESH NODE...',
            '[04/04] ESTABLISHING 5.8 GHz BEAMFORMING LINK...',
          ];

    let stepIndex = 0;
    setAuthStepText(handshakeSteps[0]);

    const stepTimer = setInterval(() => {
      stepIndex++;
      if (stepIndex < handshakeSteps.length) {
        setAuthStepText(handshakeSteps[stepIndex]);
      } else {
        clearInterval(stepTimer);
        finalizeAuthentication();
      }
    }, 600);
  };

  const finalizeAuthentication = () => {
    setIsAuthenticating(false);
    const result = validateLoginPassword(password);

    if (result.isAdmin) {
      soundEngine.playAccessGranted();
      soundEngine.speak(
        language === 'bn'
          ? 'রুট ওভাররাইড অনুমোদিত। এডমিন কমান্ড সেন্টারে স্বাগতম।'
          : 'Root Command Override Authorized. Welcome, Commander Siyam.'
      );
      recordNewScanTicket(deviceName + ' [ROOT COMMANDER]');
      onAdminAccess();
      return;
    }

    if (result.isValid) {
      soundEngine.playAccessGranted();
      soundEngine.speakAccessGranted();
      setIsConnected(true);
      recordNewScanTicket(deviceName);
    } else {
      soundEngine.playAccessDenied();
      soundEngine.speakAccessDenied();
      setErrorNotice(
        language === 'bn'
          ? 'ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন। (পাসওয়ার্ড: Siyam bhai)'
          : 'ACCESS DENIED // INVALID ENCRYPTION KEY. (Key: Siyam bhai)'
      );
    }
  };

  const handleDisconnect = () => {
    soundEngine.playClick();
    setIsConnected(false);
    setPassword('');
    setErrorNotice(null);
    if (language === 'bn') {
      soundEngine.speak('নেটওয়ার্ক সংযোগ বিচ্ছিন্ন করা হয়েছে।');
    } else {
      soundEngine.speak('Network disconnected. Quantum link offline.');
    }
  };

  return (
    <div className="relative w-full max-w-xl mx-auto px-4 z-10 animate-fadeIn">
      {/* Central Cyber Glass Card */}
      <div className="relative cyber-card cyber-scanner rounded-2xl p-6 sm:p-8 backdrop-blur-xl transition-all duration-500">
        {/* Futuristic Corner HUD Accents */}
        <div className="hud-corner hud-corner-tl" />
        <div className="hud-corner hud-corner-tr" />
        <div className="hud-corner hud-corner-bl" />
        <div className="hud-corner hud-corner-br" />

        {/* Scan line effect overlay */}
        <div className="scanlines rounded-2xl" />

        {/* Card Header Status Row */}
        <div className="relative z-10 flex items-center justify-between border-b border-[#00D9FF]/20 pb-3 mb-6 font-mono text-xs">
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                isConnected
                  ? 'bg-[#00FF66] shadow-[0_0_10px_#00FF66]'
                  : 'bg-[#00D9FF] shadow-[0_0_10px_#00D9FF] animate-ping'
              }`}
            />
            <span className="text-[#00D9FF] font-semibold tracking-wider">
              {isConnected ? 'LINK_STATE: ESTABLISHED' : 'LINK_STATE: READY'}
            </span>
          </div>

          <div className="flex items-center gap-3 text-gray-400">
            <span className="hidden sm:inline text-[10px] text-gray-500">FREQ: 5.8GHz</span>
            <span className="text-[#00FF66] font-bold text-[11px]">TURBO MESH</span>
          </div>
        </div>

        {/* Brand Banner with Crown & Animated WiFi */}
        <div className="relative z-10 text-center mb-6">
          <div className="relative inline-flex items-center justify-center mb-3">
            {/* Glowing background halo */}
            <div className="absolute inset-0 bg-[#00FF66]/20 blur-xl rounded-full animate-pulse" />

            <div className="relative w-20 h-20 rounded-2xl bg-[#020506]/90 border border-[#00FF66]/50 flex flex-col items-center justify-center shadow-[0_0_30px_rgba(0,255,102,0.3)]">
              <span className="text-xl -mt-1">👑</span>
              <Wifi
                className={`w-8 h-8 ${
                  isConnected
                    ? 'text-[#00FF66] animate-bounce'
                    : isAuthenticating
                    ? 'text-[#00D9FF] animate-spin'
                    : 'text-[#00FF66] animate-pulse'
                }`}
              />
            </div>
          </div>

          <h1 className="font-['Orbitron'] text-2xl sm:text-3xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-[#00FF66] via-[#00D9FF] to-[#A855F7] drop-shadow-[0_0_15px_rgba(0,255,102,0.4)]">
            SIYAM X
          </h1>
          <div className="font-['Orbitron'] text-xs sm:text-sm font-semibold tracking-[0.3em] text-[#00D9FF] mt-0.5">
            CYBER EMPIRE
          </div>
          <div className="text-[10px] text-gray-400 font-mono tracking-widest uppercase mt-1">
            THE FUTURE IS CONNECTED
          </div>

          {/* Dual Bilingual Welcome Prompt */}
          <div className="mt-4 p-3 rounded-xl bg-[#062417]/60 border border-[#00FF66]/30 text-center space-y-1">
            <p className="text-xs sm:text-sm font-bold text-white leading-relaxed">
              &quot;সিয়ামের ডিজিটাল সাম্রাজ্যে আপনাকে স্বাগতম!&quot;
            </p>
            <p className="text-[11px] text-gray-300 leading-normal">
              {language === 'bn'
                ? 'প্রযুক্তির নতুন দুনিয়ায় প্রবেশ করুন। দ্রুতগতির ইন্টারনেট উপভোগ করতে আপনার WiFi Password প্রবেশ করুন।'
                : 'Enter into the realm of hyper-connectivity. Supply your quantum WiFi credentials to unlock gigabit access.'}
            </p>
          </div>
        </div>

        {/* State 1: Active Connected Screen */}
        {isConnected ? (
          <div className="relative z-10 space-y-5 animate-fadeIn">
            {/* Green ACCESS GRANTED Animation Burst */}
            <div className="p-4 rounded-xl bg-[#062417] border-2 border-[#00FF66] shadow-[0_0_35px_rgba(0,255,102,0.35)] text-center space-y-1.5 animate-pulse">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#00FF66]/20 border border-[#00FF66] text-[#00FF66] font-['Orbitron'] font-black text-xs tracking-widest">
                <ShieldCheck className="w-4 h-4" />
                ACCESS GRANTED
              </div>
              <h2 className="text-sm sm:text-base font-bold text-white font-['Orbitron']">
                {language === 'bn'
                  ? 'সিয়ামের সুপারফাস্ট নেটওয়ার্কে সংযুক্ত!'
                  : 'AUTHENTICATED TO SIYAM X ULTRA MESH'}
              </h2>
              <p className="text-xs text-[#00FF66] font-mono">
                ENCRYPTED TUNNEL ACTIVE • ZERO RESTRICTIONS
              </p>
            </div>

            {/* Network Telemetry Dashboard */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center font-mono text-xs">
              <div className="p-2.5 rounded-xl bg-black/60 border border-[#00FF66]/20">
                <span className="text-[10px] text-gray-400 block">BANDWIDTH</span>
                <span className="font-['Orbitron'] text-white font-bold text-sm">1.2 Gbps</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/60 border border-[#00D9FF]/20">
                <span className="text-[10px] text-gray-400 block">LATENCY</span>
                <span className="font-['Orbitron'] text-[#00D9FF] font-bold text-sm">
                  {pingSpeed} ms
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/60 border border-[#A855F7]/20">
                <span className="text-[10px] text-gray-400 block">THROUGHPUT</span>
                <span className="font-['Orbitron'] text-[#A855F7] font-bold text-sm">
                  {liveBytes} MB/s
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/60 border border-emerald-500/20">
                <span className="text-[10px] text-gray-400 block">SIGNAL</span>
                <span className="font-['Orbitron'] text-[#00FF66] font-bold text-sm">100% 5G</span>
              </div>
            </div>

            {/* Device Info */}
            <div className="p-3 rounded-xl bg-[#020506] border border-gray-800 flex items-center justify-between text-xs font-mono">
              <span className="text-gray-400">AUTHENTICATED HOST:</span>
              <span className="text-[#00D9FF] font-bold">{deviceName}</span>
            </div>

            {/* Disconnect & Reset Button */}
            <button
              onClick={handleDisconnect}
              className="w-full py-3 px-4 rounded-xl bg-rose-950/70 hover:bg-rose-900 border border-rose-800 text-rose-300 font-['Orbitron'] font-bold text-xs tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-[0_0_20px_rgba(244,63,94,0.2)]"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{language === 'bn' ? 'সংযোগ বিচ্ছিন্ন করুন' : 'DISCONNECT QUANTUM LINK'}</span>
            </button>
          </div>
        ) : (
          /* State 2: Login Input Form */
          <form onSubmit={handleConnect} className="relative z-10 space-y-4">
            {/* Input Group */}
            <div>
              <label
                htmlFor="wifi-password-input"
                className="block text-left text-xs font-mono text-[#00D9FF] mb-2 tracking-wider flex items-center justify-between"
              >
                <span className="flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-[#00FF66]" />
                  <span>
                    {language === 'bn' ? 'ওয়াইফাই পাসওয়ার্ড লিখুন:' : 'ENTER QUANTUM SECURITY KEY:'}
                  </span>
                </span>
                <span className="text-[10px] text-gray-500">AES-256</span>
              </label>

              <div className="relative">
                <input
                  id="wifi-password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isAuthenticating}
                  placeholder={
                    language === 'bn'
                      ? 'পাসওয়ার্ড লিখুন (যেমন: Siyam bhai)...'
                      : 'ENTER PASSCODE (e.g. Siyam bhai)...'
                  }
                  className="w-full py-3.5 pl-4 pr-12 rounded-xl bg-[#020506]/90 border border-[#00FF66]/40 text-white font-mono placeholder-gray-600 text-sm outline-none focus:border-[#00FF66] focus:ring-2 focus:ring-[#00FF66]/30 shadow-[inset_0_2px_8px_rgba(0,0,0,0.8)] transition-all"
                  autoComplete="off"
                />

                <button
                  type="button"
                  onClick={handleToggleShowPassword}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1.5 text-gray-400 hover:text-[#00FF66] transition-colors"
                  aria-label="Toggle password visibility"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error Notification */}
            {errorNotice && (
              <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-600/60 text-rose-300 text-xs font-mono flex items-center gap-2.5 animate-fadeIn">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{errorNotice}</span>
              </div>
            )}

            {/* Loading / Decrypting handshake status */}
            {isAuthenticating && (
              <div className="p-3 rounded-xl bg-[#062417] border border-[#00FF66] text-[#00FF66] font-mono text-xs text-center space-y-2 animate-pulse">
                <div className="flex items-center justify-center gap-2">
                  <Activity className="w-4 h-4 animate-spin text-[#00D9FF]" />
                  <span className="font-bold">{authStepText}</span>
                </div>
                <div className="w-full bg-black/60 rounded-full h-1.5 overflow-hidden">
                  <div className="bg-gradient-to-r from-[#00D9FF] to-[#00FF66] h-full w-full animate-pulse" />
                </div>
              </div>
            )}

            {/* Glowing CONNECT TO NETWORK Button */}
            <button
              type="submit"
              disabled={isAuthenticating}
              className="relative w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-[#00FF66] via-[#00D9FF] to-[#00FF66] text-black font-['Orbitron'] font-black text-sm tracking-wider uppercase shadow-[0_0_30px_rgba(0,255,102,0.4)] hover:shadow-[0_0_40px_rgba(0,217,255,0.6)] hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed overflow-hidden group"
            >
              {/* Shimmer line */}
              <div className="absolute inset-0 bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              <div className="relative flex items-center justify-center gap-2">
                <Zap className="w-4 h-4 fill-black" />
                <span>
                  {isAuthenticating
                    ? language === 'bn'
                      ? 'প্রমাণীকরণ চলছে...'
                      : 'AUTHENTICATING...'
                    : language === 'bn'
                    ? 'নেটওয়ার্কে যুক্ত হন (CONNECT)'
                    : 'CONNECT TO NETWORK'}
                </span>
              </div>
            </button>
          </form>
        )}

        {/* Quick Cyber Actions & Spec Toggles */}
        <div className="relative z-10 mt-6 pt-4 border-t border-[#00D9FF]/15 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
          <button
            type="button"
            onClick={() => {
              soundEngine.playClick();
              setPassword('Siyam bhai');
            }}
            className="text-[11px] text-gray-400 hover:text-[#00FF66] flex items-center gap-1 transition-colors"
          >
            <span>💡</span>
            <span>{language === 'bn' ? 'পাসওয়ার্ড অটোফিল' : 'Auto-fill Passcode'}</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onOpenHelp}
              className="text-[11px] text-[#00D9FF] hover:underline flex items-center gap-1"
            >
              <Terminal className="w-3 h-3" />
              <span>{language === 'bn' ? 'সহায়তা' : 'HELP'}</span>
            </button>
            <span className="text-gray-700">•</span>
            <button
              type="button"
              onClick={onOpenAbout}
              className="text-[11px] text-[#A855F7] hover:underline flex items-center gap-1"
            >
              <Globe className="w-3 h-3" />
              <span>{language === 'bn' ? 'পরিচিতি' : 'ABOUT'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
