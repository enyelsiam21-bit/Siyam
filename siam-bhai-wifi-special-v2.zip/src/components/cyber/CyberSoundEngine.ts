/**
 * CyberSoundEngine.ts
 * Sci-Fi Audio Synthesizer & Cinematic AI Robotic Voice Engine for SIYAM X
 */

class CyberSoundEngine {
  private ctx: AudioContext | null = null;
  private soundEnabled: boolean = true;
  private voiceEnabled: boolean = true;
  private language: 'bn' | 'en' = 'bn';

  constructor() {
    // Lazily initialize AudioContext upon user interaction
  }

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setSoundEnabled(enabled: boolean) {
    this.soundEnabled = enabled;
  }

  public isSoundEnabled(): boolean {
    return this.soundEnabled;
  }

  public setVoiceEnabled(enabled: boolean) {
    this.voiceEnabled = enabled;
  }

  public isVoiceEnabled(): boolean {
    return this.voiceEnabled;
  }

  public setLanguage(lang: 'bn' | 'en') {
    this.language = lang;
  }

  public getLanguage(): 'bn' | 'en' {
    return this.language;
  }

  // Sci-Fi Web Audio SFX Synthesizer
  public playClick() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(1400, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(320, this.ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.05);
    } catch {
      // Audio autoplay policy fallback
    }
  }

  public playRadarPing() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(880, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1760, this.ctx.currentTime + 0.25);

      gain.gain.setValueAtTime(0.06, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.35);
    } catch {}
  }

  public playScanHum() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc1 = this.ctx.createOscillator();
      const osc2 = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(110, this.ctx.currentTime);
      osc1.frequency.linearRampToValueAtTime(440, this.ctx.currentTime + 1.2);

      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(220, this.ctx.currentTime);
      osc2.frequency.linearRampToValueAtTime(880, this.ctx.currentTime + 1.2);

      gain.gain.setValueAtTime(0.05, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 1.2);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(this.ctx.destination);

      osc1.start();
      osc2.start();
      osc1.stop(this.ctx.currentTime + 1.2);
      osc2.stop(this.ctx.currentTime + 1.2);
    } catch {}
  }

  public playAccessGranted() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      // Sci-fi triumphant chord arpeggio
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        const startTime = this.ctx.currentTime + idx * 0.08;
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, startTime);

        gain.gain.setValueAtTime(0.08, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.4);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(startTime);
        osc.stop(startTime + 0.45);
      });
    } catch {}
  }

  public playAccessDenied() {
    if (!this.soundEnabled) return;
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, this.ctx.currentTime);
      osc.frequency.setValueAtTime(110, this.ctx.currentTime + 0.12);

      gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start();
      osc.stop(this.ctx.currentTime + 0.35);
    } catch {}
  }

  // Cinematic Deep Robotic AI Voice
  public speak(text: string, forceLanguage?: 'bn' | 'en') {
    if (!this.voiceEnabled) return;
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    try {
      window.speechSynthesis.cancel(); // Stop any pending speech

      const utterance = new SpeechSynthesisUtterance(text);
      const activeLang = forceLanguage || this.language;

      // Deep cinematic robotic parameters
      utterance.pitch = 0.82; // Deep bass frequency
      utterance.rate = 0.92;  // Deliberate, authoritative cadence
      utterance.volume = 1.0;

      const voices = window.speechSynthesis.getVoices();
      if (activeLang === 'bn') {
        const bnVoice = voices.find((v) => v.lang.startsWith('bn'));
        if (bnVoice) {
          utterance.voice = bnVoice;
          utterance.lang = 'bn-BD';
        } else {
          // If Bengali voice is unavailable on host device, try English fallback with robotic delivery
          utterance.lang = 'en-US';
        }
      } else {
        const maleEnVoice = voices.find(
          (v) =>
            v.lang.startsWith('en') &&
            (v.name.toLowerCase().includes('male') ||
              v.name.toLowerCase().includes('david') ||
              v.name.toLowerCase().includes('george') ||
              v.name.toLowerCase().includes('robot') ||
              v.name.toLowerCase().includes('google us english'))
        ) || voices.find((v) => v.lang.startsWith('en'));

        if (maleEnVoice) {
          utterance.voice = maleEnVoice;
        }
        utterance.lang = 'en-US';
      }

      window.speechSynthesis.speak(utterance);
    } catch {}
  }

  // Pre-configured cinematic announcements
  public speakWelcome() {
    if (this.language === 'bn') {
      this.speak('সিয়ামের ডিজিটাল সাম্রাজ্যে আপনাকে স্বাগতম। কোয়ান্টাম সংযোগ স্থাপনের জন্য প্রমাণীকরণ করুন।');
    } else {
      this.speak('Welcome to Siyam X Cyber Empire. Authenticate to establish quantum link.');
    }
  }

  public speakConnecting() {
    if (this.language === 'bn') {
      this.speak('কোয়ান্টাম সিগন্যাল বিশ্লেষণ করা হচ্ছে। অনুগ্রহ করে অপেক্ষা করুন।');
    } else {
      this.speak('Establishing encrypted handshake with Siyam X network.');
    }
  }

  public speakAccessGranted() {
    if (this.language === 'bn') {
      this.speak('এক্সেস অনুমোদিত। সিয়ামের সুপারফাস্ট সাইবার সাম্রাজ্যে প্রবেশ সম্পন্ন।');
    } else {
      this.speak('Access Granted. Welcome to the Siyam X Cyber Empire, Commander.');
    }
  }

  public speakAccessDenied() {
    if (this.language === 'bn') {
      this.speak('এক্সেস প্রত্যাখ্যাত। সঠিক কোয়ান্টাম সিকিউরিটি পাসওয়ার্ড প্রদান করুন।');
    } else {
      this.speak('Access Denied. Invalid encryption key.');
    }
  }
}

export const soundEngine = new CyberSoundEngine();
