import React, { useEffect, useRef } from 'react';

export const MatrixRainCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Matrix characters: katakana, numbers, hex, and cyber symbols
    const chars = '0123456789ABCDEFSIYAMXアカサタナハマヤラワガザダバパイキシチニヒミリヰギジヂビピウクスツヌフムユルグズヅブプエケセテネヘメレヱゲゼデベペオコソトノホモヨロヲゴゾドボポ';
    const fontSize = 14;
    let columns = Math.floor(width / fontSize);
    let drops: number[] = Array.from({ length: columns }, () => Math.floor(Math.random() * -50));

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
      columns = Math.floor(width / fontSize);
      drops = Array.from({ length: columns }, () => Math.floor(Math.random() * -50));
    };

    window.addEventListener('resize', handleResize);

    let lastDraw = 0;
    const fpsInterval = 1000 / 30; // 30 FPS for smooth, battery-friendly rendering

    const draw = (timestamp: number) => {
      animationFrameId = requestAnimationFrame(draw);

      const elapsed = timestamp - lastDraw;
      if (elapsed < fpsInterval) return;
      lastDraw = timestamp - (elapsed % fpsInterval);

      // Semi-transparent fade trail
      ctx.fillStyle = 'rgba(2, 5, 6, 0.12)';
      ctx.fillRect(0, 0, width, height);

      ctx.font = `${fontSize}px 'Share Tech Mono', monospace`;

      for (let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        const x = i * fontSize;
        const y = drops[i] * fontSize;

        // Randomly highlight the head of the drop with bright white or cyan
        const isHead = Math.random() > 0.85;
        if (isHead) {
          ctx.fillStyle = '#FFFFFF';
          ctx.shadowBlur = 8;
          ctx.shadowColor = '#00D9FF';
        } else if (Math.random() > 0.95) {
          ctx.fillStyle = '#00D9FF';
          ctx.shadowBlur = 6;
          ctx.shadowColor = '#00D9FF';
        } else {
          ctx.fillStyle = '#00FF66';
          ctx.shadowBlur = 3;
          ctx.shadowColor = '#00FF66';
        }

        ctx.fillText(text, x, y);
        ctx.shadowBlur = 0; // reset shadow

        if (y > height && Math.random() > 0.975) {
          drops[i] = 0;
        }

        drops[i]++;
      }
    };

    animationFrameId = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0 opacity-40 mix-blend-screen"
    />
  );
};
