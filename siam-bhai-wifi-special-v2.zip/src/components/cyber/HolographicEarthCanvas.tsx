import React, { useEffect, useRef } from 'react';

export const HolographicEarthCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // 3D globe parameters
    let rotation = 0;
    const radius = Math.min(width, height) * 0.28;
    const globeCenter = {
      x: width * 0.5,
      y: height * 0.45,
    };

    // Node points on the sphere surface (latitude / longitude)
    const numNodes = 75;
    const nodes: { lat: number; lon: number; pulse: number }[] = [];
    for (let i = 0; i < numNodes; i++) {
      nodes.push({
        lat: (Math.random() - 0.5) * Math.PI,
        lon: Math.random() * Math.PI * 2,
        pulse: Math.random() * Math.PI * 2,
      });
    }

    let ringAngle = 0;

    const render = () => {
      animId = requestAnimationFrame(render);
      ctx.clearRect(0, 0, width, height);

      globeCenter.x = width * 0.5;
      globeCenter.y = height * 0.45;
      const currentRadius = Math.min(width, height) * 0.28;

      rotation += 0.005;
      ringAngle += 0.015;

      // Draw faint outer cyan/purple atmospheric halo
      const radialGlow = ctx.createRadialGradient(
        globeCenter.x,
        globeCenter.y,
        currentRadius * 0.7,
        globeCenter.x,
        globeCenter.y,
        currentRadius * 1.4
      );
      radialGlow.addColorStop(0, 'rgba(0, 217, 255, 0.08)');
      radialGlow.addColorStop(0.6, 'rgba(168, 85, 247, 0.04)');
      radialGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');

      ctx.fillStyle = radialGlow;
      ctx.beginPath();
      ctx.arc(globeCenter.x, globeCenter.y, currentRadius * 1.4, 0, Math.PI * 2);
      ctx.fill();

      // Draw Latitude Rings (horizontal slices)
      const latCount = 7;
      for (let i = -latCount; i <= latCount; i++) {
        const lat = (i / (latCount + 1)) * (Math.PI / 2);
        const yOffset = Math.sin(lat) * currentRadius;
        const ringRad = Math.cos(lat) * currentRadius;

        ctx.strokeStyle = 'rgba(0, 255, 102, 0.12)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        // Ellipse representing tilted circle
        ctx.ellipse(
          globeCenter.x,
          globeCenter.y + yOffset,
          ringRad,
          ringRad * 0.28,
          0,
          0,
          Math.PI * 2
        );
        ctx.stroke();
      }

      // Draw Longitude Rings (meridians rotated in 3D)
      const lonCount = 10;
      for (let i = 0; i < lonCount; i++) {
        const lon = (i / lonCount) * Math.PI + rotation;
        ctx.strokeStyle = 'rgba(0, 217, 255, 0.14)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.ellipse(
          globeCenter.x,
          globeCenter.y,
          Math.abs(Math.sin(lon)) * currentRadius,
          currentRadius,
          0,
          0,
          Math.PI * 2
        );
        ctx.stroke();
      }

      // Project and draw holographic nodes on globe surface
      const projectedNodes: { x: number; y: number; z: number; pulse: number }[] = [];

      nodes.forEach((n) => {
        n.pulse += 0.05;
        const currentLon = n.lon + rotation;
        // 3D coordinates
        const x3 = currentRadius * Math.cos(n.lat) * Math.sin(currentLon);
        const y3 = currentRadius * Math.sin(n.lat);
        const z3 = currentRadius * Math.cos(n.lat) * Math.cos(currentLon);

        // Only draw points on the front hemisphere (z > -currentRadius * 0.2)
        if (z3 > -currentRadius * 0.25) {
          const alpha = (z3 + currentRadius * 0.25) / (currentRadius * 1.25);
          const px = globeCenter.x + x3;
          const py = globeCenter.y + y3 * 0.95;

          projectedNodes.push({ x: px, y: py, z: z3, pulse: n.pulse });

          // Draw node dot
          ctx.fillStyle = `rgba(0, 255, 102, ${Math.min(1, alpha * 0.85)})`;
          ctx.beginPath();
          ctx.arc(px, py, 2 + Math.sin(n.pulse) * 1, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      // Connect nearby projected nodes with cyan laser lines
      ctx.strokeStyle = 'rgba(0, 217, 255, 0.1)';
      ctx.lineWidth = 0.8;
      for (let i = 0; i < projectedNodes.length; i++) {
        for (let j = i + 1; j < projectedNodes.length; j++) {
          const dx = projectedNodes[i].x - projectedNodes[j].x;
          const dy = projectedNodes[i].y - projectedNodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < currentRadius * 0.35) {
            ctx.beginPath();
            ctx.moveTo(projectedNodes[i].x, projectedNodes[i].y);
            ctx.lineTo(projectedNodes[j].x, projectedNodes[j].y);
            ctx.stroke();
          }
        }
      }

      // Draw Neon Green & Electric Blue Tilted Orbital Scanning Rings
      // Ring 1: Electric Blue / Cyan
      ctx.save();
      ctx.translate(globeCenter.x, globeCenter.y);
      ctx.rotate(-0.35); // tilt angle
      ctx.strokeStyle = 'rgba(0, 217, 255, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.ellipse(0, 0, currentRadius * 1.35, currentRadius * 0.45, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Satellite blip on Ring 1
      const satX = Math.cos(ringAngle) * (currentRadius * 1.35);
      const satY = Math.sin(ringAngle) * (currentRadius * 0.45);
      ctx.fillStyle = '#00D9FF';
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#00D9FF';
      ctx.beginPath();
      ctx.arc(satX, satY, 3.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Ring 2: Neon Green Counter-Rotating Ring
      ctx.save();
      ctx.translate(globeCenter.x, globeCenter.y);
      ctx.rotate(0.42); // opposite tilt
      ctx.strokeStyle = 'rgba(0, 255, 102, 0.28)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.ellipse(0, 0, currentRadius * 1.5, currentRadius * 0.4, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Satellite blip on Ring 2
      const sat2X = Math.cos(-ringAngle * 0.8) * (currentRadius * 1.5);
      const sat2Y = Math.sin(-ringAngle * 0.8) * (currentRadius * 0.4);
      ctx.fillStyle = '#00FF66';
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#00FF66';
      ctx.beginPath();
      ctx.arc(sat2X, sat2Y, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0 opacity-60 mix-blend-screen"
    />
  );
};
