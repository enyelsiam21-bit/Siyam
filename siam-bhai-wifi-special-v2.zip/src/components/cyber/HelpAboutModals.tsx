/**
 * HelpAboutModals.tsx
 * Sci-Fi Holographic Dialogs for Help & About in SIYAM X Cyber Empire
 */

import React from 'react';
import { X, ShieldAlert, Cpu, Wifi, Globe, Terminal, CheckCircle2, Zap } from 'lucide-react';
import { soundEngine } from './CyberSoundEngine';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'bn' | 'en';
}

export const HelpModal: React.FC<ModalProps> = ({ isOpen, onClose, language }) => {
  if (!isOpen) return null;

  const handleClose = () => {
    soundEngine.playClick();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg cyber-card border border-[#00D9FF]/40 rounded-xl p-6 shadow-[0_0_40px_rgba(0,217,255,0.25)] text-left">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-[#00D9FF]/20 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#00D9FF]/10 border border-[#00D9FF]/30 flex items-center justify-center text-[#00D9FF]">
              <Wifi className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-['Orbitron'] text-lg font-bold text-[#00D9FF] tracking-wider">
                {language === 'bn' ? 'সংযোগ সহায়তা ও নির্দেশিকা' : 'CONNECTION PROTOCOL & HELP'}
              </h3>
              <p className="text-xs text-[#00FF66] font-mono">NODE_STATUS: ONLINE // 5.8 GHz</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-4 text-sm text-gray-300 font-mono">
          <div className="p-3 rounded-lg bg-[#062417]/80 border border-[#00FF66]/30">
            <div className="flex items-center gap-2 text-[#00FF66] font-bold text-xs uppercase mb-1">
              <CheckCircle2 className="w-4 h-4" />
              {language === 'bn' ? 'কীভাবে যুক্ত হবেন?' : 'HOW TO AUTHENTICATE'}
            </div>
            <p className="text-xs text-gray-300 leading-relaxed">
              {language === 'bn'
                ? 'সিয়ামের সাইবার নেটওয়ার্কে যুক্ত হতে আপনার ডিভাইসে "Siyam bhai" টাইপ করে CONNECT বাটনে চাপ দিন। কোনো স্পেলিং ভুল করবেন না।'
                : 'Enter your designated authentication key "Siyam bhai" into the terminal and tap CONNECT TO NETWORK. Key sensitivity is active.'}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-lg bg-[#020506] border border-[#00D9FF]/20">
              <span className="text-gray-400 block text-[10px]">SSID IDENTIFIER</span>
              <span className="text-[#00D9FF] font-bold">SIYAM_X_5G_ULTRA</span>
            </div>
            <div className="p-3 rounded-lg bg-[#020506] border border-[#A855F7]/20">
              <span className="text-gray-400 block text-[10px]">ENCRYPTION STANDARD</span>
              <span className="text-[#A855F7] font-bold">WPA3-ENTERPRISE-GCM</span>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-black/50 border border-gray-800 space-y-1.5 text-xs">
            <div className="text-gray-400 font-bold flex items-center gap-1.5 text-[#00D9FF]">
              <Terminal className="w-3.5 h-3.5" />
              {language === 'bn' ? 'ট্রাবলশুটিং টিপস:' : 'TROUBLESHOOTING TIPS:'}
            </div>
            <ul className="list-disc list-inside text-gray-400 space-y-1 text-[11px]">
              <li>
                {language === 'bn'
                  ? 'সংযোগ না পেলে ডিভাইসের WiFi অফ করে আবার অন করুন।'
                  : 'If signal drops, toggle device WiFi radio and re-scan.'}
              </li>
              <li>
                {language === 'bn'
                  ? 'এডমিন বা রুট এক্সেসের জন্য অথরাইজড মাস্টার কী ব্যবহার করুন।'
                  : 'System administrators may execute root override with level-2 credentials.'}
              </li>
            </ul>
          </div>
        </div>

        {/* Footer Button */}
        <div className="mt-5 pt-3 border-t border-[#00D9FF]/20 flex justify-end">
          <button
            onClick={handleClose}
            className="px-5 py-2 rounded-lg bg-[#00D9FF] text-black font-['Orbitron'] font-bold text-xs tracking-wider hover:bg-[#00D9FF]/90 transition-all shadow-[0_0_15px_rgba(0,217,255,0.4)]"
          >
            {language === 'bn' ? 'বুঝেছি / বন্ধ করুন' : 'ACKNOWLEDGE & CLOSE'}
          </button>
        </div>
      </div>
    </div>
  );
};

export const AboutModal: React.FC<ModalProps> = ({ isOpen, onClose, language }) => {
  if (!isOpen) return null;

  const handleClose = () => {
    soundEngine.playClick();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg cyber-card border border-[#00FF66]/40 rounded-xl p-6 shadow-[0_0_40px_rgba(0,255,102,0.25)] text-left">
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-[#00FF66]/20 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#00FF66]/10 border border-[#00FF66]/30 flex items-center justify-center text-[#00FF66]">
              <Cpu className="w-5 h-5 animate-spin" style={{ animationDuration: '8s' }} />
            </div>
            <div>
              <h3 className="font-['Orbitron'] text-lg font-bold text-[#00FF66] tracking-wider">
                SIYAM X — CYBER EMPIRE
              </h3>
              <p className="text-xs text-[#00D9FF] font-mono">QUANTUM NETWORK SYSTEM V1.0</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-4 text-sm text-gray-300 font-mono">
          <div className="p-3.5 rounded-lg bg-[#020506] border border-[#00FF66]/25">
            <p className="text-xs text-gray-300 leading-relaxed">
              {language === 'bn'
                ? 'সিয়াম এক্স হলো একটি অত্যাধুনিক সাইবার নেটওয়ার্ক ও ফিউচারিস্টিক কানেক্টিভিটি হাব। সর্বোচ্চ গতি, জিরো-ল্যাটেন্সি এবং সামরিক গ্রেড এনক্রিপশনের মাধ্যমে প্রতিটি নাগরিককে সংযুক্ত রাখাই আমাদের লক্ষ্য।'
                : 'SIYAM X is an ultra-premium cyber infrastructure built for unrestricted gigabit connectivity, quantum security, and next-generation mesh communication.'}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-2.5 text-center text-xs">
            <div className="p-3 rounded-lg bg-black/60 border border-[#00FF66]/20">
              <Zap className="w-4 h-4 text-[#00FF66] mx-auto mb-1" />
              <div className="text-[10px] text-gray-400">BANDWIDTH</div>
              <div className="text-white font-bold font-['Orbitron']">1.2 Gbps</div>
            </div>
            <div className="p-3 rounded-lg bg-black/60 border border-[#00D9FF]/20">
              <Globe className="w-4 h-4 text-[#00D9FF] mx-auto mb-1" />
              <div className="text-[10px] text-gray-400">LATENCY</div>
              <div className="text-[#00D9FF] font-bold font-['Orbitron']">&lt; 1 ms</div>
            </div>
            <div className="p-3 rounded-lg bg-black/60 border border-[#A855F7]/20">
              <ShieldAlert className="w-4 h-4 text-[#A855F7] mx-auto mb-1" />
              <div className="text-[10px] text-gray-400">PROTOCOL</div>
              <div className="text-[#A855F7] font-bold font-['Orbitron']">QUANTUM</div>
            </div>
          </div>

          <div className="p-3 rounded-lg bg-[#062417]/40 border border-[#00FF66]/20 text-[11px] text-gray-400">
            <div className="flex items-center gap-1.5 text-[#00FF66] font-bold mb-1">
              <span>👑</span>
              <span>CHIEF ARCHITECT: SIYAM</span>
            </div>
            <p>
              {language === 'bn'
                ? 'ডিজিটাল স্বাধীনতার জন্য নির্মিত। সিয়াম ভাইয়ের সাইবার নেটওয়ার্কে সবাইকে স্বাগতম।'
                : 'Engineered for digital freedom and supreme velocity. All rights reserved by Siyam Cyber Command.'}
            </p>
          </div>
        </div>

        {/* Footer Button */}
        <div className="mt-5 pt-3 border-t border-[#00FF66]/20 flex justify-end">
          <button
            onClick={handleClose}
            className="px-5 py-2 rounded-lg bg-[#00FF66] text-black font-['Orbitron'] font-bold text-xs tracking-wider hover:bg-[#00FF66]/90 transition-all shadow-[0_0_15px_rgba(0,255,102,0.4)]"
          >
            {language === 'bn' ? 'বন্ধ করুন' : 'CLOSE TERMINAL'}
          </button>
        </div>
      </div>
    </div>
  );
};
