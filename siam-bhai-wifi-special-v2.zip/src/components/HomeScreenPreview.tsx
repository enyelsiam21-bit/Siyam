import React, { useState, useEffect } from 'react';
import {
  Wifi,
  Battery,
  Signal,
  Bell,
  Clock,
  X,
  Smartphone,
  ShieldCheck,
  Send,
  CheckCircle2,
} from 'lucide-react';
import {
  getAdminBroadcastMessage,
  getTimeUntilNext5AM,
  isFreeWifiWindowActive,
  triggerNativeMobileNotification,
} from '../utils/rules';
import { soundManager } from '../utils/audio';
import { isNativeApp, requestNativePermission, scheduleDaily5AMNotification } from '../utils/nativeNotifications';

interface HomeScreenPreviewProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HomeScreenPreview: React.FC<HomeScreenPreviewProps> = ({ isOpen, onClose }) => {
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [notificationActive, setNotificationActive] = useState<boolean>(true);
  const [broadcastMessage, setBroadcastMessage] = useState<string>(getAdminBroadcastMessage());
  const [permissionStatus, setPermissionStatus] = useState<NotificationPermission>('default');
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPermissionStatus(Notification.permission);
    }

    const timer = setInterval(() => {
      setCurrentTime(new Date());
      setBroadcastMessage(getAdminBroadcastMessage());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!isOpen) return null;

  const timeTo5AM = getTimeUntilNext5AM(currentTime);
  const isCurrentlyInWifiWindow = isFreeWifiWindowActive(currentTime);

  const formatPhoneTime = (d: Date) => {
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const handleRequestPermissionAndSend = async () => {
    soundManager.playNotificationSound();
    setNotificationActive(true);

    if (isNativeApp()) {
      const granted = await requestNativePermission();
      if (granted) {
        await triggerNativeMobileNotification('সিয়াম ভাই Free WiFi', broadcastMessage);
        await scheduleDaily5AMNotification(broadcastMessage);
        setPermissionStatus('granted');
        setFeedbackNotice('ফোনের নোটিফিকেশন বারে পাঠানো হয়েছে এবং প্রতিদিন ভোর ৫টায় আসবে!');
      } else {
        setFeedbackNotice('নোটিফিকেশন পারমিশন দেওয়া হয়নি। ফোনের Settings থেকে চালু করুন।');
      }
    } else if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const permission = await Notification.requestPermission();
        setPermissionStatus(permission);

        if (permission === 'granted') {
          await triggerNativeMobileNotification('সিয়াম ভাই Free WiFi', broadcastMessage);
          setFeedbackNotice('মোবাইলে সরাসরি সিস্টেম পুশ নোটিফিকেশন পাঠানো হয়েছে!');
        } else {
          setFeedbackNotice('মোবাইল হোম স্ক্রিনে নোটিফিকেশন প্রদর্শন করা হয়েছে।');
        }
      } catch {
        setFeedbackNotice('হোম স্ক্রিন নোটিফিকেশন সক্রিয় করা হয়েছে।');
      }
    } else {
      setFeedbackNotice('মোবাইল স্ক্রিনে পুশ নোটিফিকেশন দেখানো হচ্ছে!');
    }

    setTimeout(() => {
      setFeedbackNotice(null);
    }, 4000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-700/80 rounded-3xl p-5 sm:p-6 shadow-2xl my-auto">
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="বন্ধ করুন"
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors z-20 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-4">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-950 text-purple-300 border border-purple-700/50 mb-1">
            <Bell className="w-3.5 h-3.5 text-purple-400" /> ভোর ৫:০০ AM মোবাইল নোটিফিকেশন
          </span>
          <h2 className="text-xl sm:text-2xl font-extrabold text-white">
            মোবাইল হোম স্ক্রিন নোটিফিকেশন সিস্টেম
          </h2>
        </div>

        {/* Realistic Mobile Phone Screen Simulator */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          <div className="md:col-span-6 flex justify-center">
            <div className="w-64 sm:w-68 h-[440px] rounded-[36px] bg-slate-950 border-4 border-slate-700 shadow-2xl p-3 relative flex flex-col justify-between overflow-hidden ring-1 ring-cyan-500/20">
              {/* Dynamic Island Notch */}
              <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-20 h-4 bg-black rounded-full z-30"></div>

              {/* Status Bar */}
              <div className="flex items-center justify-between text-[10px] text-slate-300 font-medium px-3 pt-1 z-20">
                <span>{formatPhoneTime(currentTime)}</span>
                <div className="flex items-center gap-1.5">
                  <Signal className="w-3 h-3 text-cyan-400" />
                  <span className="text-[9px] text-cyan-400 font-bold">5G</span>
                  <Wifi className="w-3 h-3 text-emerald-400" />
                  <Battery className="w-3 h-3 text-white" />
                </div>
              </div>

              {/* Lock Screen Time */}
              <div className="text-center mt-4 relative z-10">
                <div className="text-4xl font-extralight tracking-tight text-white font-mono">
                  05:00
                </div>
                <div className="text-[11px] text-slate-300 mt-0.5">
                  ভোর ০৫:০০ AM
                </div>
              </div>

              {/* Notification Banner on Phone Screen */}
              <div className="my-auto px-1 z-20">
                {notificationActive ? (
                  <div className="p-3 rounded-2xl bg-slate-900/95 border border-cyan-400/40 shadow-xl backdrop-blur-xl animate-fade-in text-left">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5">
                        <div className="w-5 h-5 rounded-md bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white">
                          <Wifi className="w-3 h-3" />
                        </div>
                        <span className="text-[11px] font-bold text-white">
                          সিয়াম ভাই (Siam Bhai)
                        </span>
                      </div>
                      <span className="text-[9px] text-cyan-300">ভোর ৫:০০ AM</span>
                    </div>

                    <h4 className="text-xs font-bold text-cyan-100 leading-snug mb-1">
                      {broadcastMessage}
                    </h4>

                    <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          soundManager.playStepChime();
                          alert('সিয়াম ভাইয়ের ফ্রি ওয়াইফাই নেটওয়ার্কে সফলভাবে কানেক্ট হয়েছে!');
                        }}
                        className="text-[10px] font-bold text-white bg-cyan-600 hover:bg-cyan-500 px-2.5 py-1 rounded-lg cursor-pointer shadow"
                      >
                        কানেক্ট করুন
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center p-3 bg-slate-900/60 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setNotificationActive(true)}
                      className="text-xs text-cyan-400 underline"
                    >
                      নোটিফিকেশন পুনরায় দেখুন
                    </button>
                  </div>
                )}
              </div>

              <div className="pb-2 text-center z-10">
                <div className="w-24 h-1 bg-white/40 rounded-full mx-auto"></div>
              </div>

              <div className="absolute inset-0 bg-gradient-to-b from-indigo-950 via-slate-950 to-cyan-950 opacity-90 pointer-events-none"></div>
            </div>
          </div>

          {/* Real Notification Permission & Trigger */}
          <div className="md:col-span-6 space-y-3">
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
              <span className="text-xs text-amber-400 font-semibold flex items-center gap-1.5 mb-1">
                <Clock className="w-3.5 h-3.5" /> ভোর ০৫:০০ AM এ পৌঁছাতে বাকি:
              </span>
              <div className="text-2xl font-mono font-black text-amber-300">
                {timeTo5AM.formatted}
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-slate-950 border border-cyan-500/30 text-xs">
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-cyan-300">ফ্রি ওয়াইফাই সময়সূচি</span>
                <span className="px-2 py-0.5 rounded-full font-bold bg-emerald-950 text-emerald-300 border border-emerald-700 text-[10px]">
                  {isCurrentlyInWifiWindow ? 'সক্রিয়' : 'নির্ধারিত সময়ে চলবে'}
                </span>
              </div>
              <div className="text-sm font-bold text-white">
                ভোর ০৫:০০ AM — বিকেল ০৫:০০ PM (শুক্রবার বন্ধ)
              </div>
            </div>

            {/* Direct Mobile Push Notification Button */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <button
                type="button"
                onClick={handleRequestPermissionAndSend}
                className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-md shadow-cyan-500/20 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Smartphone className="w-4 h-4" />
                <span>সরাসরি মোবাইলে নোটিফিকেশন পাঠান (Push Notification)</span>
              </button>

              {permissionStatus === 'granted' ? (
                <div className="flex items-center justify-center gap-1 text-[11px] text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>মোবাইল নোটিফিকেশন পারমিশন সক্রিয় রয়েছে</span>
                </div>
              ) : (
                <div className="text-[11px] text-slate-400 text-center">
                  বাটনে ক্লিক করলে মোবাইল সিস্টেম নোটিফিকেশন পারমিশন চাইবে
                </div>
              )}

              {feedbackNotice && (
                <div className="p-2 bg-emerald-950/80 border border-emerald-500/40 rounded-lg text-emerald-300 text-[11px] text-center font-medium animate-fade-in">
                  ✓ {feedbackNotice}
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800 text-center">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold cursor-pointer"
          >
            বন্ধ করুন (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
