import React, { useState, useEffect } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { StepPraises } from './components/StepPraises';
import { WifiScanView } from './components/WifiScanView';
import { DeviceNameModal } from './components/DeviceNameModal';
import { AdminPanel } from './components/AdminPanel';
import { Navbar } from './components/Navbar';
import { MatrixBackground } from './components/MatrixBackground';
import { triggerNativeMobileNotification, DEFAULT_5AM_MESSAGE, getAdminBroadcastMessage } from './utils/rules';
import {
  isNativeApp,
  scheduleWifiAlarms,
  showNativeNotificationNow,
  CHANNEL_BROADCAST,
} from './utils/nativeNotifications';
import { useWifiAutomation } from './utils/useWifiAutomation';
import { cloudEnabled, subscribeLatestBroadcast, adminSignOut } from './utils/cloud';
import { initPushForDevice, unsubscribeAdminTopic } from './utils/push';
import { soundManager } from './utils/audio';
import { WifiOff } from 'lucide-react';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') return true;
      return localStorage.getItem('siam_bhai_logged_in') === 'true';
    }
    return false;
  });

  const [isAdminView, setIsAdminView] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('admin') === '1') return true;
      return localStorage.getItem('siam_is_admin') === 'true';
    }
    return false;
  });

  const [currentStepIndex, setCurrentStepIndex] = useState<number>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const stepParam = params.get('step');
      if (stepParam) {
        const parsed = parseInt(stepParam, 10);
        if (!isNaN(parsed) && parsed >= 1 && parsed <= 10) return parsed - 1;
      }
    }
    return 0;
  });
  const [showDeviceNameModal, setShowDeviceNameModal] = useState<boolean>(false);
  const [userDeviceName, setUserDeviceName] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('siam_user_device_name') || '';
    }
    return '';
  });
  const [isWifiScanMode, setIsWifiScanMode] = useState<boolean>(false);
  const [isOnline, setIsOnline] = useState<boolean>(() => {
    return typeof navigator !== 'undefined' ? navigator.onLine : true;
  });

  // ভোর ৫টা (১০ বার) + বিকেল ৫টার ভয়েস ঘোষণা (অ্যাপ খোলা থাকলে); শুক্রবার বন্ধ
  useWifiAutomation(isLoggedIn);

  // মোবাইল অ্যাপে (APK): পারমিশন → ফোনের অ্যালার্ম সেট → পুশ নোটিফিকেশন চালু
  useEffect(() => {
    if (!isLoggedIn) return;

    if (isNativeApp()) {
      scheduleWifiAlarms();
      if (cloudEnabled) initPushForDevice();
      return;
    }

    // ওয়েব ব্রাউজারে আগের মতোই কাজ করবে
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'default') {
        Notification.requestPermission().then((permission) => {
          if (permission === 'granted') {
            triggerNativeMobileNotification('সিয়াম ভাই', DEFAULT_5AM_MESSAGE);
          }
        });
      } else if (Notification.permission === 'granted') {
        triggerNativeMobileNotification('সিয়াম ভাই', DEFAULT_5AM_MESSAGE);
      }
    }
  }, [isLoggedIn]);

  // ক্লাউড থেকে এডমিনের সর্বশেষ মেসেজ — অ্যাপে সেভ করে; অ্যাপ খোলা থাকলে ফোনের নোটিফিকেশনও দেখায়
  // (অ্যাপ বন্ধ/ব্যাকগ্রাউন্ডে থাকলে FCM পুশ নিজেই নোটিফিকেশন দেখায়, তাই ডুপ্লিকেট হয় না)
  useEffect(() => {
    if (!isLoggedIn || !cloudEnabled) return;
    const unsub = subscribeLatestBroadcast((b) => {
      try {
        localStorage.setItem('siam_active_broadcast', b.text);
        const lastId = localStorage.getItem('siam_last_broadcast_id');
        if (lastId === b.id) return;
        localStorage.setItem('siam_last_broadcast_id', b.id);
        const isFresh = Date.now() - b.sentAtMs < 10 * 60 * 1000;
        const isVisible = typeof document !== 'undefined' && document.visibilityState === 'visible';
        if (isFresh && isVisible) {
          soundManager.playNotificationSound();
          if (isNativeApp()) {
            showNativeNotificationNow('⚡ সিয়াম ভাই Free WiFi', b.text, CHANNEL_BROADCAST);
          } else {
            triggerNativeMobileNotification('⚡ সিয়াম ভাই Free WiFi', b.text);
          }
        }
      } catch {
        // ignore
      }
    });
    return () => {
      if (unsub) unsub();
    };
  }, [isLoggedIn]);

  // Online / offline detector
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleLoginSuccess = (isAdmin?: boolean) => {
    setIsLoggedIn(true);
    if (typeof window !== 'undefined') {
      localStorage.setItem('siam_bhai_logged_in', 'true');
      if (isAdmin) {
        localStorage.setItem('siam_is_admin', 'true');
        setIsAdminView(true);
      } else {
        localStorage.removeItem('siam_is_admin');
        setIsAdminView(false);
      }
    }
  };

  const handleLogout = () => {
    soundManager.stopSpeech();
    setIsLoggedIn(false);
    setIsAdminView(false);
    setCurrentStepIndex(0);
    setIsWifiScanMode(false);
    setShowDeviceNameModal(false);
    if (typeof window !== 'undefined') {
      localStorage.removeItem('siam_bhai_logged_in');
      localStorage.removeItem('siam_is_admin');
    }
    if (cloudEnabled) {
      unsubscribeAdminTopic();
      adminSignOut();
    }
  };

  // Called when 10th step completes
  const handleOpenDeviceNameModal = () => {
    soundManager.stopSpeech();
    setShowDeviceNameModal(true);
  };

  // Called when user submits their device name
  const handleSubmitDeviceName = (deviceName: string) => {
    setUserDeviceName(deviceName);
    if (typeof window !== 'undefined') {
      localStorage.setItem('siam_user_device_name', deviceName);
    }
    setShowDeviceNameModal(false);
    setIsWifiScanMode(true);
  };

  const handleResetToSteps = () => {
    soundManager.stopSpeech();
    setIsWifiScanMode(false);
    setCurrentStepIndex(0);
  };

  return (
    <div className="min-h-screen bg-[#020612] text-slate-100 flex flex-col selection:bg-[#00ff66] selection:text-black relative">
      {/* Real-time Falling Matrix Code Rain & Scanlines Background */}
      <MatrixBackground />

      {!isLoggedIn ? (
        <LoginScreen onLoginSuccess={handleLoginSuccess} />
      ) : (
        <>
          {/* Navigation Header */}
          {!isAdminView && (
            <Navbar
              isOnline={isOnline}
              onLogout={handleLogout}
            />
          )}

          {/* Offline Alert Strip */}
          {!isOnline && (
            <div className="bg-amber-950/90 border-b border-amber-600/50 py-1 px-4 text-center text-xs text-amber-200 flex items-center justify-center gap-1.5 font-mono">
              <WifiOff className="w-3.5 h-3.5 text-amber-400" />
              <span>OFFLINE_MODE ACTIVE // অফলাইন মোডে সকল ফিচার কার্যকর</span>
            </div>
          )}

          {/* Main Container */}
          <main className="flex-1 flex flex-col justify-center py-4 sm:py-6">
            {isAdminView ? (
              <AdminPanel
                onBackToUserView={() => setIsAdminView(false)}
                onLogout={handleLogout}
              />
            ) : isWifiScanMode ? (
              <WifiScanView
                deviceName={userDeviceName}
                onResetSteps={handleResetToSteps}
              />
            ) : (
              <StepPraises
                currentStepIndex={currentStepIndex}
                onStepChange={(newIndex) => setCurrentStepIndex(newIndex)}
                onOpenDeviceNameModal={handleOpenDeviceNameModal}
              />
            )}
          </main>

          {/* Clean Footer */}
          {!isAdminView && (
            <footer className="py-2.5 text-center text-xs text-slate-500 border-t border-[#00ff66]/20 font-mono">
              <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-1.5">
                <span className="text-slate-400">⚡ SIYAM INFINITY NETWORK</span>
                <span className="text-[#00ff66]">ভোর ০৫:০০ AM - বিকেল ০৫:০০ PM ফ্রি 5G WiFi (শুক্রবার বন্ধ)</span>
              </div>
            </footer>
          )}

          {/* Device Name Modal after Step 10 */}
          <DeviceNameModal
            isOpen={showDeviceNameModal}
            onSubmitDeviceName={handleSubmitDeviceName}
          />
        </>
      )}
    </div>
  );
}

