export interface PraiseStep {
  id: number;
  title: string;
  badge: string;
  description: string;
  praiseQuote: string;
  voiceText: string;
  iconName: string;
  themeColor: string;
  accentGlow: string;
}

export interface WifiNetwork {
  ssid: string;
  signal: number;
  speed: string;
  isSiamBhai: boolean;
  status: 'connecting' | 'connected' | 'scanned' | 'unlocked';
  frequency: string;
}

export interface AdminMessage {
  id: string;
  text: string;
  sender: string;
  timestamp: string;
  isActiveForHomeNotification: boolean;
}

export interface ScanAlertTicket {
  id: string;
  deviceName: string;
  userDevice: string;
  timestamp: string;
  status: 'pending' | 'resolved';
  networkFound: string;
  phoneAlertSent: boolean;
  phoneNotificationText: string;
}
