import { PraiseStep, WifiNetwork, AdminMessage, ScanAlertTicket } from '../types';
import { isNativeApp, showNativeNotificationNow } from './nativeNotifications';
import { WIFI_ON_MESSAGE, getTimeUntilNextOpening } from './schedule';

export const PRAISE_STEPS: PraiseStep[] = [
  {
    id: 1,
    title: 'পরোপকারী ও মহানুভব হৃদয়ের প্রতীক',
    badge: 'ধাপ ০১ • মানবতার কাণ্ডারি',
    description: 'সিয়াম ভাই সবসময় নিঃস্বার্থভাবে এলাকার সবার বিপদে-আপদে পাশে দাঁড়ান। মানুষের মুখে হাসি ফোটানোই তাঁর জীবনের মূল লক্ষ্য।',
    praiseQuote: '“অন্যের প্রয়োজনে যার হৃদয় সবার আগে জেগে ওঠে, তিনিই আমাদের প্রিয় সিয়াম ভাই।”',
    voiceText: 'ধাপ এক। সিয়াম ভাই একজন পরোপকারী ও মহানুভব ব্যক্তিত্ব। তিনি সবসময় মানুষের কল্যাণে কাজ করেন।',
    iconName: 'heart',
    themeColor: 'from-emerald-500 to-teal-700',
    accentGlow: 'rgba(16, 185, 129, 0.25)',
  },
  {
    id: 2,
    title: 'প্রযুক্তি ও নেটওয়ার্কের কিংবদন্তি প্রতিভা',
    badge: 'ধাপ ০২ • আইটি জিনিয়াস',
    description: 'যেকোনো আইটি সমস্যা বা ইন্টারনেট জটিলতায় সিয়াম ভাইয়ের দক্ষতা অতুলনীয়। তাঁর সুদক্ষ নির্দেশনায় জটিল সমস্যার সমাধান হয় সেকেন্ডে।',
    praiseQuote: '“যেখানে অন্যরা হতাশ হয়ে ফিরে আসে, সেখান থেকেই সিয়াম ভাইয়ের জাদুকরী সমাধান শুরু হয়।”',
    voiceText: 'ধাপ দুই। প্রযুক্তি ও নেটওয়ার্কের কিংবদন্তি প্রতিভা আমাদের সিয়াম ভাই। যেকোনো জটিল নেটওয়ার্ক সমাধান তাঁর কাছে খুব সহজ।',
    iconName: 'cpu',
    themeColor: 'from-cyan-500 to-blue-700',
    accentGlow: 'rgba(6, 182, 212, 0.25)',
  },
  {
    id: 3,
    title: 'ফ্রি ওয়াইফাই ও ডিজিটাল বিপ্লবের অগ্রদূত',
    badge: 'ধাপ ০৩ • ডিজিটাল বিপ্লব',
    description: 'নিজের খরচে পাড়া-মহল্লায় হাই-স্পিড ফ্রি ওয়াইফাই নেটওয়ার্ক উপহার দিয়ে তরুণদের পড়াশোনা ও ফ্রিল্যান্সিংয়ে বিশাল সুযোগ তৈরি করেছেন।',
    praiseQuote: '“তথ্যপ্রযুক্তির আলো সবার মাঝে ছড়িয়ে দিতে সিয়াম ভাইয়ের ফ্রি ওয়াইফাই উদ্যোগ এক যুগান্তকারী দৃষ্টান্ত।”',
    voiceText: 'ধাপ তিন। সিয়াম ভাই ফ্রি ওয়াইফাই সেবার অগ্রদূত। সবার জন্য তিনি দিয়েছেন উচ্চগতির ফ্রি ইন্টারনেট সুবিধা।',
    iconName: 'wifi',
    themeColor: 'from-teal-500 to-emerald-800',
    accentGlow: 'rgba(20, 184, 166, 0.25)',
  },
  {
    id: 4,
    title: 'অক্লান্ত পরিশ্রমী ও দায়িত্বশীল সেবক',
    badge: 'ধাপ ০৪ • একনিষ্ঠ কর্মী',
    description: 'রাত-দিন যখনই কারো নেটওয়ার্কে সমস্যা হয়, সিয়াম ভাই বিন্দুমাত্র দ্বিধা না করে নিরবচ্ছিন্ন সমাধান নিশ্চিত করেন।',
    praiseQuote: '“যার কাছে দায়িত্ব কেবল মুখের কথা নয়, কাজের মাধ্যমে প্রমাণিত এক অনন্য আদর্শ।”',
    voiceText: 'ধাপ চার। সিয়াম ভাই একজন অক্লান্ত পরিশ্রমী ও দায়িত্বশীল নেতা। দিনরাত মানুষের সেবায় তিনি নিয়োজিত।',
    iconName: 'shield',
    themeColor: 'from-amber-500 to-emerald-700',
    accentGlow: 'rgba(245, 158, 11, 0.25)',
  },
  {
    id: 5,
    title: 'তরুণ প্রজন্মের অনুপ্রেরণা ও পথপ্রদর্শক',
    badge: 'ধাপ ০৫ • যুব সমাজের আইকন',
    description: 'তিনি তরুণদের শুধু ফ্রি নেটওয়ার্ক দেন না, বরং সঠিক কাজে ক্যারিয়ার গড়ার মূল্যবান দিকনির্দেশনা ও জীবনবোধের শিক্ষা দেন।',
    praiseQuote: '“সঠিক দিকনির্দেশনার জন্য একজন আদর্শ অভিভাবক হলেন আমাদের প্রিয় সিয়াম ভাই।”',
    voiceText: 'ধাপ পাঁচ। তরুণ প্রজন্মের জন্য সিয়াম ভাই এক অনন্য অনুপ্রেরণা ও পথপ্রদর্শক।',
    iconName: 'sparkles',
    themeColor: 'from-emerald-400 to-indigo-700',
    accentGlow: 'rgba(52, 211, 153, 0.25)',
  },
  {
    id: 6,
    title: 'শান্ত, ভদ্র ও অমায়িক ব্যবহার',
    badge: 'ধাপ ০৬ • মার্জিত চরিত্র',
    description: 'সিয়াম ভাইয়ের মুখে সবসময় আন্তরিক হাসি লেগে থাকে। ছোট-বড় সবার সাথে পরম শ্রদ্ধা ও ভালোবাসার সাথে কথা বলেন।',
    praiseQuote: '“মানুষ তাঁর মেধার চেয়েও বেশি মুগ্ধ হয় সিয়াম ভাইয়ের অমায়িক ও মধুর ব্যবহারে।”',
    voiceText: 'ধাপ ছয়। সিয়াম ভাইয়ের শান্ত ও অমায়িক ব্যবহার সবার হৃদয় জয় করে নেয়। সবার প্রতি তাঁর ভালোবাসা অকৃত্রিম।',
    iconName: 'smile',
    themeColor: 'from-emerald-500 to-teal-600',
    accentGlow: 'rgba(16, 185, 129, 0.25)',
  },
  {
    id: 7,
    title: 'সততা ও নীতির আপসহীন প্রতীক',
    badge: 'ধাপ ০৭ • নীতি ও সততা',
    description: 'প্রতিটি কাজে স্বচ্ছতা এবং ন্যায্যতার অনন্য প্রতীক সিয়াম ভাই। মানুষের নিঃস্বার্থ ভালোবাসাই তাঁর সবচেয়ে বড় সম্পদ।',
    praiseQuote: '“লোভ-লালসার ঊর্ধ্বে উঠে মানবতার জয়গান গাওয়া মানুষটির নাম সিয়াম ভাই।”',
    voiceText: 'ধাপ সাত। সততা ও নীতিতে সিয়াম ভাই আপসহীন। মানুষের ভালোবাসাই তাঁর আসল শক্তি।',
    iconName: 'award',
    themeColor: 'from-amber-400 to-yellow-600',
    accentGlow: 'rgba(251, 191, 36, 0.25)',
  },
  {
    id: 8,
    title: 'সবার ভরসার নির্ভরযোগ্য ঠিকানা',
    badge: 'ধাপ ০৮ • পরম নির্ভরতা',
    description: 'নেটওয়ার্ক ডাউন হোক বা ব্যক্তিগত কোনো জটিলতা, এলাকার প্রতিটি মানুষ জানে সিয়াম ভাই থাকলে সমাধান হবেই।',
    praiseQuote: '“যেখানে সিয়াম ভাইয়ের ছায়া আছে, সেখানে কোনো সমস্যা বেশি সময় টেকে না।”',
    voiceText: 'ধাপ আট। সিয়াম ভাই এলাকার প্রতিটি মানুষের পরম ভরসার নির্ভরযোগ্য ঠিকানা।',
    iconName: 'anchor',
    themeColor: 'from-teal-600 to-cyan-700',
    accentGlow: 'rgba(13, 148, 136, 0.25)',
  },
  {
    id: 9,
    title: 'নিখাদ ভ্রাতৃত্বের উজ্জ্বল দৃষ্টান্ত',
    badge: 'ধাপ ০৯ • ভালোবাসার বন্ধন',
    description: 'ছোটদের স্নেহ আর বড়দের শ্রদ্ধায় বেঁধে রাখার দারুণ মানবিক গুণ রয়েছে আমাদের প্রিয় ভাইয়ের।',
    praiseQuote: '“ভাই তো অনেকেই হতে পারে, কিন্তু সিয়াম ভাইয়ের মতো হৃদয়ের ভাই সচরাচর মেলে না।”',
    voiceText: 'ধাপ নয়। অকৃত্রিম বন্ধুত্ব ও নিখাদ ভ্রাতৃত্বের অনন্য প্রতীক আমাদের প্রিয় সিয়াম ভাই।',
    iconName: 'users',
    themeColor: 'from-emerald-600 to-indigo-800',
    accentGlow: 'rgba(5, 150, 105, 0.25)',
  },
  {
    id: 10,
    title: 'মহৎ হৃদয়ের চিরদিনের অবিসংবাদিত নায়ক',
    badge: 'ধাপ ১০ • আমাদের সেরা নায়ক',
    description: '১০টি ধাপে সিয়াম ভাইয়ের যত গুণগানই করা হোক, তা কম হবে। তিনি আমাদের অন্তরের গর্ব, ডিজিটাল অভিভাবক ও অনুপ্রেরণা।',
    praiseQuote: '“সিয়াম ভাই দীর্ঘজীবী হোন! আপনার অসামান্য অবদান আমরা শ্রদ্ধার সাথে চিরকাল স্মরণ রাখবো।”',
    voiceText: 'ধাপ দশ। সিয়াম ভাই আমাদের মনের মণিকোঠায় থাকা সেরা নায়ক। আপনার প্রতিটি অবদানের জন্য আমরা চিরকৃতজ্ঞ।',
    iconName: 'crown',
    themeColor: 'from-amber-400 via-emerald-500 to-teal-700',
    accentGlow: 'rgba(245, 158, 11, 0.35)',
  },
];

export const MOCK_WIFI_NETWORKS: WifiNetwork[] = [
  {
    ssid: '🌟 SIAM-BHAI-FREE-WIFI-5G 🌟',
    signal: 100,
    speed: '1200 Mbps (Turbo Ultra 5G)',
    isSiamBhai: true,
    status: 'unlocked',
    frequency: '5.8 GHz & 6 GHz Turbo',
  },
];

export const REQUIRED_LOGIN_PASSWORD = 'Siyam bhai';
export const ADMIN_PASSWORD = 'Siyam 99';

export function validateLoginPassword(input: string): { isValid: boolean; message: string; isAdmin?: boolean } {
  if (!input || input.trim() === '') {
    return { isValid: false, message: 'অনুগ্রহ করে পাসওয়ার্ড লিখুন!' };
  }
  const clean = input.trim();

  // Admin access
  if (clean.toLowerCase() === ADMIN_PASSWORD.toLowerCase()) {
    return { isValid: true, message: 'এডমিন এক্সেস অনুমোদিত!', isAdmin: true };
  }

  // Exact or case-insensitive match for "Siyam bhai"
  if (clean.toLowerCase() === REQUIRED_LOGIN_PASSWORD.toLowerCase()) {
    return { isValid: true, message: 'লগইন সফল হয়েছে।' };
  }

  return {
    isValid: false,
    message: 'ভুল পাসওয়ার্ড! অনুগ্রহ করে সঠিক পাসওয়ার্ড দিন।',
  };
}

export function validateAdminPassword(input: string): boolean {
  if (!input) return false;
  return input.trim().toLowerCase() === ADMIN_PASSWORD.toLowerCase();
}

export const DEFAULT_5AM_MESSAGE = 'সিয়াম ভাই free wifi নেট চালু করা হয়েছে ভোর চারটা থেকে বিকেল পাঁচটা পরযন্ত';
export const RESOLUTION_MESSAGE = 'দুই ঘণ্টার মধ্যে আপনার সমস্যাটি সমাধান করা হচ্ছে';

const ADMIN_MESSAGES_KEY = 'siam_admin_messages_v3';
const SCAN_TICKETS_KEY = 'siam_scan_tickets_v3';

// Cross-tab broadcast channel
let broadcastChannel: BroadcastChannel | null = null;
if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
  try {
    broadcastChannel = new BroadcastChannel('siam_bhai_channel');
  } catch {
    broadcastChannel = null;
  }
}

export function getAdminBroadcastMessage(): string {
  if (typeof window === 'undefined') return DEFAULT_5AM_MESSAGE;
  try {
    const saved = localStorage.getItem('siam_active_broadcast');
    return saved && saved.trim() !== '' ? saved : DEFAULT_5AM_MESSAGE;
  } catch {
    return DEFAULT_5AM_MESSAGE;
  }
}

export function saveAdminBroadcastMessage(newMsg: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem('siam_active_broadcast', newMsg);
    const existingRaw = localStorage.getItem(ADMIN_MESSAGES_KEY);
    const existing: AdminMessage[] = existingRaw ? JSON.parse(existingRaw) : [];
    const item: AdminMessage = {
      id: 'MSG-' + Date.now(),
      text: newMsg,
      sender: 'সিয়াম ভাই (Admin)',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isActiveForHomeNotification: true,
    };
    existing.unshift(item);
    localStorage.setItem(ADMIN_MESSAGES_KEY, JSON.stringify(existing.slice(0, 10)));

    // Send real mobile push notification if permission granted
    triggerNativeMobileNotification('সিয়াম ভাই Free WiFi অ্যালার্ট', newMsg);

    // Notify other tabs
    if (broadcastChannel) {
      broadcastChannel.postMessage({ type: 'BROADCAST_UPDATED', message: newMsg });
    }
  } catch {
    // safe fallback
  }
}

export function getScanAlertTickets(): ScanAlertTicket[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(SCAN_TICKETS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function recordNewScanTicket(deviceName: string): ScanAlertTicket {
  const cleanDevice = deviceName?.trim() || 'অজানা ডিভাইস';
  const newTicket: ScanAlertTicket = {
    id: 'TKT-' + (Date.now().toString(36).slice(-5) + Math.random().toString(36).slice(2, 4)).toUpperCase(),
    deviceName: cleanDevice,
    userDevice: cleanDevice,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    status: 'pending',
    networkFound: 'SIAM-BHAI-FREE-WIFI-5G (100%)',
    phoneAlertSent: true,
    phoneNotificationText: `সিয়াম ভাইয়ের ফোনে মেসেজ পাঠানো হয়েছে: ব্যবহারকারী [${cleanDevice}] সফলভাবে WiFi স্ক্যান করেছেন। ২ ঘণ্টার মধ্যে সমাধান সম্পন্ন হবে।`,
  };

  if (typeof window !== 'undefined') {
    try {
      const tickets = getScanAlertTickets();
      tickets.unshift(newTicket);
      localStorage.setItem(SCAN_TICKETS_KEY, JSON.stringify(tickets.slice(0, 30)));

      if (broadcastChannel) {
        broadcastChannel.postMessage({ type: 'NEW_SCAN_TICKET', ticket: newTicket });
      }
    } catch {
      // ignore
    }
  }

  return newTicket;
}

export function markTicketResolved(ticketId: string): void {
  if (typeof window === 'undefined') return;
  try {
    const tickets = getScanAlertTickets();
    const updated = tickets.map((t) => (t.id === ticketId ? { ...t, status: 'resolved' as const } : t));
    localStorage.setItem(SCAN_TICKETS_KEY, JSON.stringify(updated));
    if (broadcastChannel) {
      broadcastChannel.postMessage({ type: 'TICKET_RESOLVED', ticketId });
    }
  } catch {
    // ignore
  }
}

/**
 * Triggers REAL OS notification on mobile/desktop
 */
export async function triggerNativeMobileNotification(title: string, body: string): Promise<boolean> {
  // APK/মোবাইল অ্যাপে হলে ফোনের আসল সিস্টেম নোটিফিকেশন ব্যবহার করবে
  if (isNativeApp()) {
    return showNativeNotificationNow(title, body);
  }

  if (typeof window === 'undefined' || !('Notification' in window)) {
    return false;
  }

  try {
    if (Notification.permission === 'granted') {
      new Notification(title, {
        body,
        icon: '/icon.svg',
        badge: '/icon.svg',
      });
      return true;
    } else if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        new Notification(title, {
          body,
          icon: '/icon.svg',
          badge: '/icon.svg',
        });
        return true;
      }
    }
  } catch {
    // fallback
  }
  return false;
}

/** পরবর্তী wifi চালুর সময় পর্যন্ত বাকি সময় (শুক্রবার বাদ দিয়ে) */
export const getTimeUntilNext5AM = getTimeUntilNextOpening;

/** ভোর ৫:০০ – বিকেল ৫:০০, শুক্রবার বাদে */
export { isFreeWifiWindowActive } from './schedule';
