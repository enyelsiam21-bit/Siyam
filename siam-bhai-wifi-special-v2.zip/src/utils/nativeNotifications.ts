import { Capacitor } from '@capacitor/core';
import {
  WIFI_ON_MESSAGE,
  WIFI_OFF_MESSAGE,
  WIFI_OPEN_HOUR,
  WIFI_CLOSE_HOUR,
  WIFI_ON_REPEAT_COUNT,
  WIFI_ON_REPEAT_GAP_SECONDS,
  getOpenWeekdaysForCapacitor,
} from './schedule';

/** Android নোটিফিকেশন চ্যানেল (সাউন্ড ফাইল: android/app/src/main/res/raw/<sound>.wav) */
export const CHANNEL_WIFI_ON = 'wifi-on';
export const CHANNEL_WIFI_OFF = 'wifi-off';
export const CHANNEL_BROADCAST = 'wifi-broadcast';

const EXACT_ASKED_KEY = 'siam_exact_alarm_asked';

// অ্যালার্মের আইডি রেঞ্জ
const ID_MORNING_BASE = 6000; // 6000 + weekdayIndex*100 + k
const ID_EVENING_BASE = 7000; // 7000 + weekdayIndex
const ID_TEST_BASE = 9000;
const LEGACY_ID = 5001;

export const isNativeApp = (): boolean => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

async function plugin() {
  const mod = await import('@capacitor/local-notifications');
  return mod.LocalNotifications;
}

/** মোবাইলের নোটিফিকেশন পারমিশন চায় */
export async function requestNativePermission(): Promise<boolean> {
  if (!isNativeApp()) return false;
  try {
    const LN = await plugin();
    const current = await LN.checkPermissions();
    if (current.display === 'granted') return true;
    const result = await LN.requestPermissions();
    return result.display === 'granted';
  } catch {
    return false;
  }
}

/** তিনটি চ্যানেল তৈরি করে (আগে থেকে থাকলে কিছু হয় না) */
export async function ensureChannels(): Promise<void> {
  if (!isNativeApp()) return;
  try {
    const LN = await plugin();
    const base = { importance: 5 as const, visibility: 1 as const, vibration: true, lights: true };
    await LN.createChannel({
      id: CHANNEL_WIFI_ON,
      name: 'wifi চালু (ভোর ৫টা)',
      description: 'সিয়াম ভাইয়ের wifi চালু করা হয়েছে',
      sound: 'wifi_on.wav',
      ...base,
    });
    await LN.createChannel({
      id: CHANNEL_WIFI_OFF,
      name: 'wifi বন্ধ (বিকেল ৫টা)',
      description: 'সিয়াম ভাই wifi বন্ধ করা হচ্ছে',
      sound: 'wifi_off.wav',
      ...base,
    });
    await LN.createChannel({
      id: CHANNEL_BROADCAST,
      name: 'এডমিন মেসেজ',
      description: 'সিয়াম ভাইয়ের পাঠানো বার্তা',
      sound: 'wifi_alert.wav',
      ...base,
    });
  } catch {
    // ignore
  }
}

/** এখনই ফোনের নোটিফিকেশন বারে নোটিফিকেশন দেখায় */
export async function showNativeNotificationNow(
  title: string,
  body: string,
  channelId: string = CHANNEL_BROADCAST
): Promise<boolean> {
  if (!isNativeApp()) return false;
  try {
    const ok = await requestNativePermission();
    if (!ok) return false;
    await ensureChannels();
    const LN = await plugin();
    await LN.schedule({
      notifications: [
        {
          id: Math.floor(Math.random() * 90000) + 10,
          title,
          body,
          channelId,
          schedule: { at: new Date(Date.now() + 500), allowWhileIdle: true },
        },
      ],
    });
    return true;
  } catch {
    return false;
  }
}

async function askExactAlarmOnce(): Promise<void> {
  try {
    const LN = await plugin();
    const exact = await LN.checkExactNotificationSetting();
    if (exact.exact_alarm !== 'granted' && !localStorage.getItem(EXACT_ASKED_KEY)) {
      localStorage.setItem(EXACT_ASKED_KEY, '1');
      await LN.changeExactNotificationSetting();
    }
  } catch {
    // পুরনো Android-এ প্রয়োজন নেই
  }
}

type AlarmDef = {
  id: number;
  title: string;
  body: string;
  channelId: string;
  weekday: number;
  hour: number;
  minute: number;
  second: number;
  type: 'wifi_on' | 'wifi_off';
};

/** সব অ্যালার্মের তালিকা (শুক্রবার বাদ) */
export function buildAlarmDefinitions(): AlarmDef[] {
  const defs: AlarmDef[] = [];
  getOpenWeekdaysForCapacitor().forEach((weekday, wIdx) => {
    for (let k = 0; k < WIFI_ON_REPEAT_COUNT; k++) {
      const totalSec = k * WIFI_ON_REPEAT_GAP_SECONDS;
      defs.push({
        id: ID_MORNING_BASE + wIdx * 100 + k,
        title: '⚡ সিয়াম ভাই WiFi',
        body: WIFI_ON_MESSAGE,
        channelId: CHANNEL_WIFI_ON,
        weekday,
        hour: WIFI_OPEN_HOUR,
        minute: Math.floor(totalSec / 60),
        second: totalSec % 60,
        type: 'wifi_on',
      });
    }
    defs.push({
      id: ID_EVENING_BASE + wIdx,
      title: '⚡ সিয়াম ভাই WiFi',
      body: WIFI_OFF_MESSAGE,
      channelId: CHANNEL_WIFI_OFF,
      weekday,
      hour: WIFI_CLOSE_HOUR,
      minute: 0,
      second: 0,
      type: 'wifi_off',
    });
  });
  return defs;
}

/**
 * ভোর ৫টা (১০ বার) ও বিকেল ৫টার অ্যালার্ম ফোনে বসায়।
 * ইন্টারনেট লাগে না। অ্যাপ বন্ধ থাকলেও, ফোন রিস্টার্ট করলেও চলবে।
 * শুক্রবারের কোনো অ্যালার্ম নেই।
 */
export async function scheduleWifiAlarms(): Promise<{ ok: boolean; count: number }> {
  if (!isNativeApp()) return { ok: false, count: 0 };
  try {
    const granted = await requestNativePermission();
    if (!granted) return { ok: false, count: 0 };
    await ensureChannels();
    await askExactAlarmOnce();

    const LN = await plugin();
    const defs = buildAlarmDefinitions();
    const wanted = new Set(defs.map((d) => d.id));

    const pending = await LN.getPending();
    const mine = pending.notifications.filter(
      (n) => n.id === LEGACY_ID || (n.id >= ID_MORNING_BASE && n.id < ID_TEST_BASE)
    );
    const have = new Set(mine.map((n) => n.id));
    const allPresent = [...wanted].every((id) => have.has(id)) && mine.length === wanted.size;
    if (allPresent) return { ok: true, count: wanted.size };

    if (mine.length) {
      await LN.cancel({ notifications: mine.map((n) => ({ id: n.id })) });
    }

    await LN.schedule({
      notifications: defs.map((d) => ({
        id: d.id,
        title: d.title,
        body: d.body,
        channelId: d.channelId,
        autoCancel: true,
        extra: { type: d.type },
        schedule: {
          on: { weekday: d.weekday, hour: d.hour, minute: d.minute, second: d.second },
          allowWhileIdle: true,
        },
      })),
    });
    return { ok: true, count: defs.length };
  } catch {
    return { ok: false, count: 0 };
  }
}

/** ফোনে এখন কতটি অ্যালার্ম সেট আছে (এডমিন প্যানেলে যাচাইয়ের জন্য) */
export async function getScheduledAlarmCount(): Promise<number> {
  if (!isNativeApp()) return 0;
  try {
    const LN = await plugin();
    const pending = await LN.getPending();
    return pending.notifications.filter((n) => n.id >= ID_MORNING_BASE && n.id < ID_TEST_BASE).length;
  } catch {
    return 0;
  }
}

/** টেস্ট: ১০ সেকেন্ড পরে ৩ বার "চালু" এবং তারপর ১ বার "বন্ধ" অ্যালার্ম বাজাবে */
export async function scheduleTestAlarms(): Promise<boolean> {
  if (!isNativeApp()) return false;
  try {
    const granted = await requestNativePermission();
    if (!granted) return false;
    await ensureChannels();
    const LN = await plugin();
    const now = Date.now();
    const list = [0, 1, 2].map((i) => ({
      id: ID_TEST_BASE + i,
      title: '🧪 টেস্ট: সিয়াম ভাই WiFi',
      body: WIFI_ON_MESSAGE,
      channelId: CHANNEL_WIFI_ON,
      extra: { type: 'wifi_on' },
      schedule: { at: new Date(now + 10000 + i * 10000), allowWhileIdle: true },
    }));
    list.push({
      id: ID_TEST_BASE + 3,
      title: '🧪 টেস্ট: সিয়াম ভাই WiFi',
      body: WIFI_OFF_MESSAGE,
      channelId: CHANNEL_WIFI_OFF,
      extra: { type: 'wifi_off' },
      schedule: { at: new Date(now + 40000), allowWhileIdle: true },
    });
    await LN.schedule({ notifications: list });
    return true;
  } catch {
    return false;
  }
}

/** নোটিফিকেশনে ট্যাপ করলে কল হবে (অ্যাপ খুলে ভয়েস বলার জন্য) */
export async function onNotificationTap(
  handler: (type: string | undefined) => void
): Promise<() => void> {
  if (!isNativeApp()) return () => {};
  try {
    const LN = await plugin();
    const sub = await LN.addListener('localNotificationActionPerformed', (event) => {
      const extra = event.notification?.extra as { type?: string } | undefined;
      handler(extra?.type);
    });
    return () => {
      sub.remove();
    };
  } catch {
    return () => {};
  }
}
