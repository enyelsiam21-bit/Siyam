import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateLoginPassword,
  validateAdminPassword,
  recordNewScanTicket,
  PRAISE_STEPS,
  DEFAULT_5AM_MESSAGE,
  RESOLUTION_MESSAGE,
  isFreeWifiWindowActive,
} from './rules';

test('User login password accepts Siyam bhai', () => {
  const result = validateLoginPassword('Siyam bhai');
  assert.equal(result.isValid, true);
});

test('Admin login password accepts Siyam 99', () => {
  assert.equal(validateAdminPassword('Siyam 99'), true);
  assert.equal(validateAdminPassword('siyam 99'), true);
  assert.equal(validateAdminPassword('wrong'), false);

  const loginRes = validateLoginPassword('Siyam 99');
  assert.equal(loginRes.isValid, true);
  assert.equal(loginRes.isAdmin, true);
});

test('recordNewScanTicket preserves user entered device name', () => {
  const ticket = recordNewScanTicket('Samsung S24 Ultra');
  assert.equal(ticket.deviceName, 'Samsung S24 Ultra');
  assert.ok(ticket.phoneNotificationText.includes('Samsung S24 Ultra'));
});

test('Exactly 10 praise steps are defined with rich tribute and theme', () => {
  assert.equal(PRAISE_STEPS.length, 10);
  PRAISE_STEPS.forEach((step, idx) => {
    assert.equal(step.id, idx + 1);
    assert.ok(step.themeColor.length > 0);
  });
});

test('Default 5 AM message matches user prompt', () => {
  assert.ok(DEFAULT_5AM_MESSAGE.includes('সিয়াম ভাই free wifi'));
  assert.ok(DEFAULT_5AM_MESSAGE.includes('ভোর চারটা থেকে বিকেল পাঁচটা'));
});

test('Resolution message matches user prompt', () => {
  assert.equal(RESOLUTION_MESSAGE, 'দুই ঘণ্টার মধ্যে আপনার সমস্যাটি সমাধান করা হচ্ছে');
});
