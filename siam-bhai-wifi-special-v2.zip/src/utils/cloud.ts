/**
 * Firebase ক্লাউড স্তর — সব ডিভাইস ও এডমিন প্যানেলের মধ্যে মেসেজ আদান-প্রদান।
 *
 * অফলাইন আচরণ:
 *  - Firestore-এর লোকাল ক্যাশ চালু আছে। ডিভাইস অফলাইনে স্ক্যান করলে টিকেট ফোনের ভেতর জমা থাকে
 *    এবং ইন্টারনেট আসা মাত্র নিজে থেকে এডমিন প্যানেলে পৌঁছে যায়।
 *  - এডমিন অফলাইনে মেসেজ লিখলেও জমা থাকে, নেট আসলে পাঠানো শুরু হয়।
 *
 * .env-এ VITE_FIREBASE_* না দিলে cloudEnabled = false এবং অ্যাপ আগের মতো শুধু লোকালি চলে।
 */
import { initializeApp, getApps } from 'firebase/app';
import {
  initializeFirestore,
  getFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  collection,
  doc,
  setDoc,
  updateDoc,
  addDoc,
  onSnapshot,
  query,
  orderBy,
  limit,
  type Firestore,
  type Unsubscribe,
} from 'firebase/firestore';
import {
  getAuth,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';
import { ScanAlertTicket } from '../types';
import { BROADCAST_DELAY_SECONDS } from './schedule';

const env = import.meta.env;

const firebaseConfig = {
  apiKey: env?.VITE_FIREBASE_API_KEY as string | undefined,
  authDomain: env?.VITE_FIREBASE_AUTH_DOMAIN as string | undefined,
  projectId: env?.VITE_FIREBASE_PROJECT_ID as string | undefined,
  storageBucket: env?.VITE_FIREBASE_STORAGE_BUCKET as string | undefined,
  messagingSenderId: env?.VITE_FIREBASE_MESSAGING_SENDER_ID as string | undefined,
  appId: env?.VITE_FIREBASE_APP_ID as string | undefined,
};

export const cloudEnabled: boolean = Boolean(
  firebaseConfig.apiKey && firebaseConfig.projectId && firebaseConfig.appId
);

export const ADMIN_EMAIL: string =
  (env?.VITE_ADMIN_EMAIL as string | undefined) || 'siam-admin@siambhai.app';

let cachedDb: Firestore | null = null;

function getApp() {
  return getApps()[0] ?? initializeApp(firebaseConfig);
}

function getDb(): Firestore | null {
  if (!cloudEnabled) return null;
  if (cachedDb) return cachedDb;
  const app = getApp();
  try {
    cachedDb = initializeFirestore(app, {
      localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    });
  } catch {
    cachedDb = getFirestore(app);
  }
  return cachedDb;
}

/* ───────────── ডিভাইস → এডমিন (স্ক্যান টিকেট) ───────────── */

/** টিকেট পাঠায়। অফলাইনে হলে ফোনে জমা থাকে, নেট আসলে নিজে থেকে চলে যায়। */
export function pushScanTicketToCloud(ticket: ScanAlertTicket): void {
  const db = getDb();
  if (!db) return;
  setDoc(doc(db, 'tickets', ticket.id), { ...ticket, createdAtMs: Date.now() }).catch(() => {});
}

export function subscribeTickets(
  onData: (tickets: ScanAlertTicket[], meta: { fromCache: boolean; pending: boolean }) => void,
  onError?: (message: string) => void
): Unsubscribe | null {
  const db = getDb();
  if (!db) return null;
  const q = query(collection(db, 'tickets'), orderBy('createdAtMs', 'desc'), limit(100));
  return onSnapshot(
    q,
    { includeMetadataChanges: true },
    (snap) => {
      onData(
        snap.docs.map((d) => d.data() as ScanAlertTicket),
        { fromCache: snap.metadata.fromCache, pending: snap.metadata.hasPendingWrites }
      );
    },
    (err) => onError?.(err.code || err.message)
  );
}

export function resolveTicketInCloud(ticketId: string): void {
  const db = getDb();
  if (!db) return;
  updateDoc(doc(db, 'tickets', ticketId), { status: 'resolved' }).catch(() => {});
}

/* ───────────── এডমিন → সব ডিভাইস (ব্রডকাস্ট) ───────────── */

/**
 * ব্রডকাস্ট জমা দেয়। Cloud Function ৩০ সেকেন্ড অপেক্ষা করে সব ফোনে একসাথে পাঠায়।
 * অফলাইনে হলে ফোনে জমা থাকে এবং নেট আসলে জমা হয়।
 */
export function sendBroadcastToCloud(text: string): boolean {
  const db = getDb();
  if (!db) return false;
  addDoc(collection(db, 'broadcasts'), {
    text,
    sender: 'সিয়াম ভাই (Admin)',
    createdAtMs: Date.now(),
    delaySeconds: BROADCAST_DELAY_SECONDS,
    status: 'scheduled',
  }).catch(() => {});
  return true;
}

export interface CloudBroadcast {
  id: string;
  text: string;
  sentAtMs: number;
}

/** সর্বশেষ পাঠানো ব্রডকাস্ট (Cloud Function যেটায় sentAtMs বসিয়েছে) */
export function subscribeLatestBroadcast(onData: (b: CloudBroadcast) => void): Unsubscribe | null {
  const db = getDb();
  if (!db) return null;
  const q = query(collection(db, 'broadcasts'), orderBy('sentAtMs', 'desc'), limit(1));
  return onSnapshot(
    q,
    (snap) => {
      const d = snap.docs[0];
      if (!d) return;
      const data = d.data() as { text?: string; sentAtMs?: number };
      if (data.text && data.sentAtMs) {
        onData({ id: d.id, text: data.text, sentAtMs: data.sentAtMs });
      }
    },
    () => {}
  );
}

/* ───────────── এডমিন সাইন-ইন ───────────── */

export async function adminSignIn(password: string): Promise<{ ok: boolean; error?: string }> {
  if (!cloudEnabled) return { ok: false, error: 'ক্লাউড সেট করা নেই' };
  try {
    await signInWithEmailAndPassword(getAuth(getApp()), ADMIN_EMAIL, password);
    return { ok: true };
  } catch (e) {
    const code = (e as { code?: string }).code || '';
    if (code === 'auth/network-request-failed') {
      return { ok: false, error: 'ইন্টারনেট নেই — প্রথমবার সাইন-ইনের জন্য নেট লাগবে' };
    }
    if (code === 'auth/invalid-credential' || code === 'auth/wrong-password' || code === 'auth/user-not-found') {
      return { ok: false, error: 'ক্লাউড পাসওয়ার্ড ভুল' };
    }
    return { ok: false, error: code || 'সাইন-ইন ব্যর্থ' };
  }
}

export async function adminSignOut(): Promise<void> {
  if (!cloudEnabled) return;
  try {
    await signOut(getAuth(getApp()));
  } catch {
    // ignore
  }
}

/** সাইন-ইন অবস্থা বদলালে কল হয় (অফলাইনেও আগের সেশন ধরে রাখে) */
export function onAdminAuthChange(cb: (signedIn: boolean) => void): Unsubscribe {
  if (!cloudEnabled) {
    cb(false);
    return () => {};
  }
  return onAuthStateChanged(getAuth(getApp()), (user) => {
    cb(Boolean(user && user.email === ADMIN_EMAIL));
  });
}
