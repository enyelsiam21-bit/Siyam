/**
 * FCM পুশ নোটিফিকেশন — অ্যাপ বন্ধ থাকলেও এডমিনের মেসেজ ফোনে আসবে।
 * ফোন অফলাইনে থাকলে Google ম্যাসেজ ধরে রাখে এবং নেট আসলে পাঠায়।
 *
 *  - সবার ফোন "all" টপিকে সাবস্ক্রাইব করে
 *  - এডমিনের ফোন অতিরিক্ত "admin" টপিকে সাবস্ক্রাইব করে (নতুন স্ক্যান আসলে জানতে)
 */
import { isNativeApp } from './nativeNotifications';

const TOPIC_ALL = 'all';
const TOPIC_ADMIN = 'admin';

async function messaging() {
  const mod = await import('@capacitor-firebase/messaging');
  return mod.FirebaseMessaging;
}

function subscribeWithRetry(topic: string, attempt = 0): void {
  messaging()
    .then((FM) => FM.subscribeToTopic({ topic }))
    .catch(() => {
      if (attempt >= 6) return;
      // নেট না থাকলে পরে আবার চেষ্টা (নেট ফিরলে বা ১ মিনিট পর)
      let done = false;
      const retry = () => {
        if (done) return;
        done = true;
        window.removeEventListener('online', retry);
        subscribeWithRetry(topic, attempt + 1);
      };
      window.addEventListener('online', retry, { once: true });
      setTimeout(retry, 60000);
    });
}

/** সব ডিভাইসের জন্য: পারমিশন চেয়ে "all" টপিকে যুক্ত হয় */
export async function initPushForDevice(): Promise<void> {
  if (!isNativeApp()) return;
  try {
    const FM = await messaging();
    const perm = await FM.requestPermissions();
    if (perm.receive !== 'granted') return;
    subscribeWithRetry(TOPIC_ALL);
  } catch {
    // ignore
  }
}

export function subscribeAdminTopic(): void {
  if (!isNativeApp()) return;
  subscribeWithRetry(TOPIC_ADMIN);
}

export async function unsubscribeAdminTopic(): Promise<void> {
  if (!isNativeApp()) return;
  try {
    const FM = await messaging();
    await FM.unsubscribeFromTopic({ topic: TOPIC_ADMIN });
  } catch {
    // ignore
  }
}
