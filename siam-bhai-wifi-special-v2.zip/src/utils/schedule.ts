/**
 * ওয়াইফাই সময়সূচি (সম্পূর্ণ অফলাইনে কাজ করে — শুধু ফোনের ঘড়ি লাগে)
 *
 *  - প্রতিদিন ভোর ০৫:০০ → "সিয়াম ভাইয়ের wifi চালু করা হয়েছে" (১০ বার)
 *  - প্রতিদিন বিকেল ০৫:০০ (১৭:০০) → "সিয়াম ভাই wifi বন্ধ করা হচ্ছে, আবার কালকে চালু হবে"
 *  - প্রতি শুক্রবার সারাদিন wifi বন্ধ (কোনো অ্যালার্ম নেই)
 */

export const WIFI_OPEN_HOUR = 5;
export const WIFI_CLOSE_HOUR = 17;
/** JavaScript Date.getDay(): 0 = রবিবার ... 5 = শুক্রবার ... 6 = শনিবার */
export const WIFI_CLOSED_JS_WEEKDAY = 5;

/** ভোর ৫টার ঘোষণা কতবার বলবে */
export const WIFI_ON_REPEAT_COUNT = 10;
/** ১০ বারের মধ্যে প্রতিটির ব্যবধান (সেকেন্ড) */
export const WIFI_ON_REPEAT_GAP_SECONDS = 10;

/** এডমিন মেসেজ পাঠানোর পর সবার ফোনে যাওয়ার আগে অপেক্ষা (সেকেন্ড) */
export const BROADCAST_DELAY_SECONDS = 30;

export const WIFI_ON_MESSAGE = 'সিয়াম ভাইয়ের wifi চালু করা হয়েছে';
export const WIFI_OFF_MESSAGE = 'সিয়াম ভাই wifi বন্ধ করা হচ্ছে, আবার কালকে চালু হবে';
export const WIFI_FRIDAY_MESSAGE = 'আজ শুক্রবার, সিয়াম ভাইয়ের wifi বন্ধ আছে';

export type WifiState =
  | 'open'
  | 'closed_friday'
  | 'closed_before_open'
  | 'closed_after_close';

export function isFriday(now: Date = new Date()): boolean {
  return now.getDay() === WIFI_CLOSED_JS_WEEKDAY;
}

export function getWifiState(now: Date = new Date()): WifiState {
  if (isFriday(now)) return 'closed_friday';
  const h = now.getHours();
  if (h < WIFI_OPEN_HOUR) return 'closed_before_open';
  if (h >= WIFI_CLOSE_HOUR) return 'closed_after_close';
  return 'open';
}

export function isFreeWifiWindowActive(now: Date = new Date()): boolean {
  return getWifiState(now) === 'open';
}

/** পরবর্তী কখন wifi চালু হবে (শুক্রবার বাদ দিয়ে) */
export function getNextOpening(now: Date = new Date()): Date {
  const next = new Date(now);
  next.setHours(WIFI_OPEN_HOUR, 0, 0, 0);
  if (next.getTime() <= now.getTime()) {
    next.setDate(next.getDate() + 1);
  }
  while (next.getDay() === WIFI_CLOSED_JS_WEEKDAY) {
    next.setDate(next.getDate() + 1);
  }
  return next;
}

export function getTimeUntilNextOpening(now: Date = new Date()): {
  hours: number;
  minutes: number;
  seconds: number;
  formatted: string;
} {
  const diffMs = getNextOpening(now).getTime() - now.getTime();
  const total = Math.max(0, Math.floor(diffMs / 1000));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const seconds = total % 60;
  const p = (n: number) => String(n).padStart(2, '0');
  return { hours, minutes, seconds, formatted: `${p(hours)}:${p(minutes)}:${p(seconds)}` };
}

/** UI-তে দেখানোর জন্য বর্তমান অবস্থার বাংলা লেখা */
export function describeWifiState(now: Date = new Date()): string {
  switch (getWifiState(now)) {
    case 'open':
      return 'wifi এখন চালু আছে (বিকেল ৫টা পর্যন্ত)';
    case 'closed_friday':
      return WIFI_FRIDAY_MESSAGE + ' — শনিবার ভোর ৫টায় আবার চালু হবে';
    case 'closed_before_open':
      return 'wifi এখন বন্ধ — ভোর ৫টায় চালু হবে';
    case 'closed_after_close':
      return isFriday(new Date(now.getTime() + 24 * 3600 * 1000))
        ? 'wifi এখন বন্ধ — কাল শুক্রবার, তাই শনিবার ভোর ৫টায় চালু হবে'
        : 'wifi এখন বন্ধ — কাল ভোর ৫টায় আবার চালু হবে';
  }
}

/**
 * Capacitor LocalNotifications-এর weekday (১ = রবিবার ... ৭ = শনিবার)
 * শুক্রবার (৬) বাদ দিয়ে বাকি ৬ দিন।
 */
export function getOpenWeekdaysForCapacitor(): number[] {
  return [0, 1, 2, 3, 4, 5, 6]
    .filter((jsDay) => jsDay !== WIFI_CLOSED_JS_WEEKDAY)
    .map((jsDay) => jsDay + 1);
}
