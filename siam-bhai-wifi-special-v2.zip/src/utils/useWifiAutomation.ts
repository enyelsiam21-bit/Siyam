import { useEffect } from 'react';
import { soundManager } from './audio';
import { onNotificationTap } from './nativeNotifications';
import {
  isFriday,
  WIFI_OPEN_HOUR,
  WIFI_CLOSE_HOUR,
  WIFI_ON_MESSAGE,
  WIFI_OFF_MESSAGE,
  WIFI_ON_REPEAT_COUNT,
} from './schedule';

const SPOKEN_KEY = 'siam_wifi_spoken_v1';
/** নির্ধারিত সময়ের কতক্ষণ পর পর্যন্ত অ্যাপ খুললে ভয়েস বলবে (সেকেন্ড) */
const GRACE_SECONDS = 180;

type EventType = 'on' | 'off';

function dayKey(d: Date): string {
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

function wasSpoken(type: EventType, now: Date): boolean {
  try {
    return localStorage.getItem(SPOKEN_KEY + ':' + type) === dayKey(now);
  } catch {
    return false;
  }
}

function markSpoken(type: EventType, now: Date): void {
  try {
    localStorage.setItem(SPOKEN_KEY + ':' + type, dayKey(now));
  } catch {
    // ignore
  }
}

function announce(type: EventType, now: Date): void {
  if (wasSpoken(type, now)) return;
  markSpoken(type, now);
  if (type === 'on') {
    soundManager.speakRepeated(WIFI_ON_MESSAGE, WIFI_ON_REPEAT_COUNT);
  } else {
    soundManager.speakRepeated(WIFI_OFF_MESSAGE, 1);
  }
}

/**
 * অ্যাপ খোলা থাকলে (বা নোটিফিকেশনে ট্যাপ করে খুললে) নির্ধারিত সময়ে ভয়েসে ঘোষণা দেয়:
 *  - ভোর ৫টা: ১০ বার "সিয়াম ভাইয়ের wifi চালু করা হয়েছে"
 *  - বিকেল ৫টা: "সিয়াম ভাই wifi বন্ধ করা হচ্ছে, আবার কালকে চালু হবে"
 *  - শুক্রবার: কিছুই বলবে না
 * অ্যাপ বন্ধ থাকলে ফোনের অ্যালার্ম নোটিফিকেশন (সাউন্ডসহ) কাজ করে।
 */
export function useWifiAutomation(enabled: boolean): void {
  useEffect(() => {
    if (!enabled) return;

    const tick = () => {
      const now = new Date();
      if (isFriday(now)) return;
      const secs = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
      const openAt = WIFI_OPEN_HOUR * 3600;
      const closeAt = WIFI_CLOSE_HOUR * 3600;
      if (secs >= openAt && secs < openAt + GRACE_SECONDS) announce('on', now);
      if (secs >= closeAt && secs < closeAt + GRACE_SECONDS) announce('off', now);
    };

    tick();
    const id = setInterval(tick, 1000);

    let removeTap: (() => void) | null = null;
    onNotificationTap((type) => {
      const now = new Date();
      if (isFriday(now)) return;
      if (type === 'wifi_on') announce('on', now);
      if (type === 'wifi_off') announce('off', now);
    }).then((remove) => {
      removeTap = remove;
    });

    return () => {
      clearInterval(id);
      if (removeTap) removeTap();
    };
  }, [enabled]);
}
