import test from 'node:test';
import assert from 'node:assert/strict';
import {
  getWifiState,
  isFreeWifiWindowActive,
  getNextOpening,
  getOpenWeekdaysForCapacitor,
  WIFI_ON_MESSAGE,
  WIFI_OFF_MESSAGE,
} from './schedule';

// 2026-11-12 = বৃহস্পতিবার, 2026-11-13 = শুক্রবার, 2026-11-14 = শনিবার
const at = (day: number, h: number, m = 0, s = 0) => new Date(2026, 10, day, h, m, s);

test('ভোর ৫টার আগে wifi বন্ধ', () => {
  assert.equal(getWifiState(at(12, 4, 59, 59)), 'closed_before_open');
  assert.equal(isFreeWifiWindowActive(at(12, 4, 59, 59)), false);
});

test('ভোর ৫:০০ থেকে বিকেল ৫:০০ পর্যন্ত চালু', () => {
  assert.equal(getWifiState(at(12, 5, 0, 0)), 'open');
  assert.equal(getWifiState(at(12, 12, 30)), 'open');
  assert.equal(getWifiState(at(12, 16, 59, 59)), 'open');
});

test('বিকেল ৫:০০ থেকে বন্ধ', () => {
  assert.equal(getWifiState(at(12, 17, 0, 0)), 'closed_after_close');
});

test('শুক্রবার সারাদিন বন্ধ', () => {
  assert.equal(getWifiState(at(13, 5, 0)), 'closed_friday');
  assert.equal(getWifiState(at(13, 12, 0)), 'closed_friday');
  assert.equal(isFreeWifiWindowActive(at(13, 12, 0)), false);
});

test('বৃহস্পতিবার বিকেলের পর পরবর্তী চালু শনিবার ভোর ৫টায়', () => {
  const next = getNextOpening(at(12, 17, 30));
  assert.equal(next.getDay(), 6);
  assert.equal(next.getDate(), 14);
  assert.equal(next.getHours(), 5);
});

test('শুক্রবার দুপুরে পরবর্তী চালু শনিবার ভোর ৫টায়', () => {
  const next = getNextOpening(at(13, 12, 0));
  assert.equal(next.getDate(), 14);
});

test('শনিবার ভোর ৩টায় পরবর্তী চালু একই দিন ৫টায়', () => {
  const next = getNextOpening(at(14, 3, 0));
  assert.equal(next.getDate(), 14);
  assert.equal(next.getHours(), 5);
});

test('অ্যালার্মের দিন: শুক্রবার (৬) বাদ', () => {
  assert.deepEqual(getOpenWeekdaysForCapacitor(), [1, 2, 3, 4, 5, 7]);
});

test('ঘোষণার বার্তা', () => {
  assert.equal(WIFI_ON_MESSAGE, 'সিয়াম ভাইয়ের wifi চালু করা হয়েছে');
  assert.ok(WIFI_OFF_MESSAGE.includes('আবার কালকে চালু হবে'));
});
